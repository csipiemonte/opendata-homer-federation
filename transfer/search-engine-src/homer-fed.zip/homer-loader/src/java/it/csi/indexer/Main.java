/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer;

import static com.google.common.base.Preconditions.checkArgument;
import it.csi.indexer.adapter.AdapterLoader;
import it.csi.indexer.ckan.CkanLoader;
import it.csi.indexer.csw.CswLoader;
import it.csi.indexer.dataloading.DataLoaderInterface;
import it.csi.indexer.dataloading.DocumentsLoader;
import it.csi.indexer.dataloading.OntologyLoader;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Properties;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(Main.class);

	public static void main(String... args) {

		Properties properties = System.getProperties();

		
		checkArgument(properties.containsKey("solr.server.url"),
				"SOLR server url non impostata: impostare la propriety� di sistema con -Dsolr.server.url=<url del server>");
		checkArgument(properties.containsKey("baseUrl"),
				"baseUrl non impostato: impostare la proprietà di sistema con -DbaseUrl=<url dove si trova la lista dei documenti da indicizzare>");
		log.info("baseUrl: " + properties.get("baseUrl"));
		try {
			String baseUrlDecoded = URLDecoder.decode(""+properties.get("baseUrl"), "UTF-8");
			log.info("baseUrl decoded: " + baseUrlDecoded);
			properties.setProperty("baseUrl", baseUrlDecoded);
			System.setProperty("baseUrl", baseUrlDecoded);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			log.error("[Main::main] ERROR: basuUrl Not valid" + e.getMessage());
			log.error("[Main::main] ERROR: basuUrl: " + properties.get("baseUrl"));
		}
		
		log.info("System.baseUrl: " + System.getProperty("baseUrl"));
		log.info("proxy : "  + System.getProperty("http.proxyHost") + ":"+System.getProperty("http.proxyPort"));

		checkArgument(properties.containsKey("cleanQuery"), "cleanQuery non impostata: impostare la proprietà di sistema  con -DcleanQuery=<query>");
		checkArgument(properties.containsKey("sourceID"),
				"sourceID non impostata: impostare la proprietà di sistema  con -DsourceID=<id della fonte indicizzate, ad esempio regionePiemonte>");

		log.info("federation.type: " + properties.getProperty("federation.type"));

		AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext();
		//ctx.scan("it.csi.indexer.config.dati");
		ctx.scan("it.csi.indexer.config.ontology");
		log.info("scan it.csi.indexer.config.dati: OK ");

		ctx.refresh();
		log.info("refresh it.csi.indexer.config.dati: OK ");
		DataLoaderInterface loader = ctx.getBean(OntologyLoader.class);
		log.info("OntologyLoader: OK ");

		loader.clean();
		log.info("OntologyLoader: clean OK ");
		loader.load();
		log.info("OntologyLoader: load OK ");

		ctx = new AnnotationConfigApplicationContext();
		loader = null;
		System.out.println("federation.type: " + properties.getProperty("federation.type"));
		log.info("federation.type: " + properties.getProperty("federation.type"));

		if (properties.containsKey("federation.type") && properties.getProperty("federation.type").equalsIgnoreCase("CKAN")) {
			ctx.scan("it.csi.indexer.config.ckan");
			ctx.refresh();
			loader = ctx.getBean(CkanLoader.class);
		} else if (properties.containsKey("federation.type") && properties.getProperty("federation.type").equalsIgnoreCase("ADAPTER")) {
			ctx.scan("it.csi.indexer.config.adapter");
			ctx.refresh();
			loader = ctx.getBean(AdapterLoader.class);
		} else if (properties.containsKey("federation.type") && properties.getProperty("federation.type").equalsIgnoreCase("CSW")) {

//			checkArgument(
//					properties.containsKey("singleItemUrl"),
//					"singleItemUrl non impostata: impostare la proprietà di sistema  con -DsingleItemUrl=<query>\n"
//							+ "Si tratta della url da cui caricare il singolo item partendo dall'id (recuperato dalla lista restituita baseUrl). Formato: http://...<id>...");
//			checkArgument(properties.containsKey("singleServiceUrl"),
//					"singleServiceUrl non impostata: impostare la proprietà di sistema  con -singleServiceUrl=<query>\n"
//							+ "Si tratta della url effettiva del servizio. Formato: http://...<uuid>...");

			ctx.scan("it.csi.indexer.config.csw");
			ctx.refresh();
			loader = ctx.getBean(CswLoader.class);
		} else {
			ctx.scan("it.csi.indexer.config.dati");
			ctx.refresh();
			loader = ctx.getBean(DocumentsLoader.class);
		}

		loader.clean();
		loader.load();

	}
}
