package it.csi.indexer.bean.csw;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "otherConstraints", namespace = "http://www.isotc211.org/2005/gmd")
public class OtherConstraints {
	@XmlElement(name="CharacterString",namespace="http://www.isotc211.org/2005/gco")
	private String value;

	public String getValue() {
		return value;
	}

}
