/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.ckan;

import static com.google.common.collect.Lists.newArrayList;
import static it.csi.indexer.ckan.CkanParser.ERROR_DOC;

import it.csi.indexer.bean.ckan.Package;

import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;

import lombok.extern.log4j.Log4j;

import org.apache.commons.httpclient.HttpClient;
import org.apache.solr.common.SolrInputDocument;
import org.codehaus.jackson.map.ObjectMapper;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * Provider di documenti: si aggancia alla url in cui trovare la lista dei
 * documenti da scaricare, scarica i singoli documenti, li parsifica e crea il
 * corrispondente documento SOLR.
 * 
 * @author CSI
 */
@Log4j
public class CkanDocumentProvider implements Iterator<SolrInputDocument> {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(CkanDocumentProvider.class);
	private final HttpClient client;
	private final String url;
	private final CkanParser parser;
	private final String encoding;
    protected ObjectMapper mapper = new ObjectMapper();

	private Iterator<String> documents;

	/**
	 * @param client
	 * @param parser
	 * @param url
	 */
	public CkanDocumentProvider(HttpClient client, CkanParser parser, String url) {
		this(client, parser, url, "UTF-8");
	}

	/**
	 * 
	 * @param client
	 * @param parser
	 * @param url
	 * @param encoding
	 */
	public CkanDocumentProvider(HttpClient client, CkanParser parser, String url, String encoding) {
		this.client = client;
		this.url = url;
		this.parser = parser;
		this.encoding = encoding;
		documents = fetchList().iterator();

	}

	private List<String> fetchList() {

		List<String> oggetti = newArrayList();

		try {
    		HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
			RestTemplate template = new RestTemplate();
			
			String query = url;
			ResponseEntity<String> entity = template.getForEntity(query, String.class);
			
		    String body = entity.getBody();
			MediaType contentType = entity.getHeaders().getContentType();
			HttpStatus statusCode = entity.getStatusCode();
			
		    if (statusCode==HttpStatus.OK /*&& contentType==MediaType.APPLICATION_JSON*/) {
			    //Map<String,Object> jsonBean = null;
			    String[] jsonBean = null;
	    		jsonBean = mapper.readValue(body, String[].class);
	
//	    		List<String> acceptedIds = new LinkedList<String>();
//	    		acceptedIds.add("814bc69e-bc2d-48b8-bc9c-e9e238122057");
//	    		acceptedIds.add("33836da0-6bd0-4cb0-9f39-f60f8e274ad5");
//	    		acceptedIds.add("e5fc77ac-2eb8-45ab-ae71-302fd0fffb65");
//	    		acceptedIds.add("e313837d-cf2a-45d8-8bb3-88d42300a1dc");
//	    		acceptedIds.add("4803b3a2-773f-4f1a-8d0a-4a9a69309c7b");
//	    		acceptedIds.add("4f6f0e27-32d8-4677-9a0b-3844e5d0d4ad");
//	    		acceptedIds.add("af9db2b2-defb-48b1-8ff1-fb1c28c219c1");
//	    		acceptedIds.add("b859ade5-19fa-40aa-9b51-d6b21ee5b103");
	    		if (jsonBean!=null && jsonBean.length>0) {
    				// decodifica 
	    			for (String id : jsonBean) {
//	    				if(acceptedIds.contains(id))
	    					oggetti.add(url+"/"+id);
	    			}
	    		}
		    }

		} catch (Exception e) {
			throw new RuntimeException("Error while retrieving ckan index", e);
		}
		return oggetti;

	}


	public boolean hasNext() {

		return documents.hasNext();
	}

	public SolrInputDocument next() {

		String query = documents.next();
		log.info("getting url content:: " + query);
		try {
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			HttpEntity<String> httpEntity = new HttpEntity<String>(headers);
			RestTemplate template = new RestTemplate();
			
			ResponseEntity<String> entity = template.getForEntity(query, String.class);
			
		    String body = entity.getBody();
			MediaType contentType = entity.getHeaders().getContentType();
			HttpStatus statusCode = entity.getStatusCode();
			
			SolrInputDocument doc = null;
			if (statusCode==HttpStatus.OK /*&& contentType==MediaType.APPLICATION_JSON*/) {
			    Package jsonBean = null;
	    		jsonBean = mapper.readValue(body, Package.class);
	
	    		doc = parser.parse(jsonBean, query, encoding);
				if (doc == ERROR_DOC) log.warn("error while parsing doc:: " + query);
			} else {
				log.warn("error while parsing doc:: " + query);
			}

			return doc;

		} catch (Exception e) {
			log.error("error while retrieving doc:: " + query, e);

			//IOUtils.closeQuietly(reader);
		}
		return ERROR_DOC;
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

}
