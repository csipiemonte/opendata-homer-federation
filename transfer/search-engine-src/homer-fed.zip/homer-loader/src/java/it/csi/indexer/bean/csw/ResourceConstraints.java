package it.csi.indexer.bean.csw;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "resourceConstraints", namespace = "http://www.isotc211.org/2005/gmd")
public class ResourceConstraints {

	@XmlElement(name = "MD_LegalConstraints", namespace = "http://www.isotc211.org/2005/gmd")
	private MDLegalConstraints MDLegalConstraints;

	public MDLegalConstraints getMDLegalConstraints() {
		return MDLegalConstraints;
	}


}
