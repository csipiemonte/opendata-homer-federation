/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.config.adapter;

import static com.google.common.collect.Sets.newHashSet;
import it.csi.indexer.adapter.AdapterDocumentProvider;
import it.csi.indexer.adapter.AdapterLoader;
import it.csi.indexer.adapter.AdapterXmlParser;

import java.net.MalformedURLException;

import org.apache.commons.httpclient.HttpClient;
import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

import com.google.common.collect.ImmutableList;

/**
 * Configurazione Spring
 * 
 * @author CSI
 */
@Configuration
@ImportResource("classpath:/META-INF/properties-config.xml")
public class AdapterLoaderBeanConfig {
	final static private String core="documents/";

	@Value("${solr.server.url}")
	private String solrServerUrl;

	@Value("${encoding}")
	private String encoding;

	@Value("${baseUrl}")
	private String baseUrl;

	@Value("${cleanQuery}")
	private String cleanQuery;

	@Value("${sourceID}")
	private String sourceID;

	@Value("${portal}")
	private String portal;

	@Value("${package.prefix}")
	private String packagePrefix;

	@Value("${resource.prefix}")
	private String resourcePrefix;

	@Value("${topic.prefix}")
	private String topicPrefix;

	@Value("${author.prefix}")
	private String authorPrefix;

	@Value("${source.url.prefix}")
	private String sourceUrlPrefix;
	
	@Value("${package.language}")
	private String language;

	private SolrServer solrServer(String core) {
		String solrServerUrl_coreSpecific=solrServerUrl;
		if(!solrServerUrl_coreSpecific.endsWith("/"))
			solrServerUrl_coreSpecific+="/"+core;
		else
			solrServerUrl_coreSpecific+=core;
		
		SolrServer server;
		try {
			server = new CommonsHttpSolrServer(solrServerUrl_coreSpecific);
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}

		return server;
	}

	@Bean
	public AdapterLoader adapterLoader() {
		//return new AdapterLoader(solrServer(), adapterProvider(), cleanQuery);
		return new AdapterLoader(solrServer("documents/"), adapterProvider(), sourceID, cleanQuery);

	}

	@Bean
	public AdapterXmlParser adapterParser() {
		
		return new AdapterXmlParser(
				ImmutableList.of("//oggetto/*",
						"//oggetto/argomenti/*",
						"//oggetto/enti/*",
						"//oggetto/tags/*"),
				ImmutableList.of("title",
						"description",
						"tag"),
				newHashSet("metadata_created", "metadata_modified", "package_created", "package_modified", "metadata_source_modified", "valid_from", "valid_to"),
				portal,
				packagePrefix,
				resourcePrefix,
				topicPrefix,
				authorPrefix,
				sourceUrlPrefix,
				language);
	}

	@Bean
	public AdapterDocumentProvider adapterProvider() {
		return new AdapterDocumentProvider(httpClient(), adapterParser(), baseUrl, encoding);
	}

	@Bean
	public HttpClient httpClient() {
		HttpClient httpClient = new HttpClient();
		httpClient.getHostConfiguration().setProxy(System.getProperty("http.proxyHost"),new Integer(System.getProperty("http.proxyPort")));
		return httpClient;

	}

}
