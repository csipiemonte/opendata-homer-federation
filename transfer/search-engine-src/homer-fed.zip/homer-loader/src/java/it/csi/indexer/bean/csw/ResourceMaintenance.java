package it.csi.indexer.bean.csw;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "resourceMaintenance", namespace = "http://www.isotc211.org/2005/gmd")
public class ResourceMaintenance {
	@XmlElement(name = "MD_MaintenanceInformation", namespace = "http://www.isotc211.org/2005/gmd")
	private MDMaintenanceInformation mdMaintenanceInformation;

	public MDMaintenanceInformation getMDMaintenanceInformation() {
		return mdMaintenanceInformation;
	}

}
