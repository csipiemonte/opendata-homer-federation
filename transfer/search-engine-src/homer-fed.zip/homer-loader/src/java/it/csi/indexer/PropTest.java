package it.csi.indexer;

public class PropTest {

	public static void main(String[] args) {
		System.out.println(System.getProperty("prop"));
	}

}