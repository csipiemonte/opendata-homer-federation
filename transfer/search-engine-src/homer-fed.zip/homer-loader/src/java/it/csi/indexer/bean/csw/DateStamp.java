package it.csi.indexer.bean.csw;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "dateStamp", namespace = "http://www.isotc211.org/2005/gmd")
public class DateStamp {
	@XmlElement(name="Date",namespace="http://www.isotc211.org/2005/gco")
	private String value;

	public String getValue() {
		return value;
	}
}
