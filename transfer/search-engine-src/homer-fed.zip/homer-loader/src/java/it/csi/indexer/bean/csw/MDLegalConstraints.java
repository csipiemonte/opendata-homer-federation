package it.csi.indexer.bean.csw;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement(name = "MD_LegalConstraints", namespace = "http://www.isotc211.org/2005/gmd")
public class MDLegalConstraints {

	@XmlElement(name = "otherConstraints", namespace = "http://www.isotc211.org/2005/gmd")
	private OtherConstraints otherConstraints;

	public OtherConstraints getOtherConstraints() {
		return otherConstraints;
	}

}
