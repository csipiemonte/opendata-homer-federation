/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.csw;

import static com.google.common.collect.Lists.newArrayList;
import static it.csi.indexer.dataloading.XMLDocumentParser.ERROR_DOC;
import it.csi.indexer.bean.ckan.Package;
import it.csi.indexer.bean.csw.GetRecords;
import it.csi.indexer.bean.csw.GetRecordsByIdResponse;
import it.csi.indexer.ckan.CkanParser;
import it.csi.indexer.util.Utils;

import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import lombok.extern.log4j.Log4j;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.solr.common.SolrInputDocument;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

/**
 * Provider di documenti: si aggncia alla url in cui trovare la lista dei
 * documeti da scaricare, scarica i singoli documenti, li parsifica e crea il
 * corrispondente documento SOLR.
 * 
 * @author franchini@celi.it
 * @author ventaglio@celi.it
 */
@Log4j
public class CswDocumentProvider implements Iterator<SolrInputDocument> {
	
	private static final String CSW_URL_PARAMETER_GET_LIST = "csw?REQUEST=GetRecords&SERVICE=CSW&VERSION=2.0.2&TYPENAMES=csw:Record&RESULTTYPE=results&OUTPUTSCHEMA=http://www.isotc211.org/2005/gmd&ELEMENTSETNAME=brief&constraintlanguage=CQL_TEXT&STARTPOSITION=<startposition>&MAXRECORDS=<maxrecords>";
	private static final String CSW_URL_PARAMETER_GET_RECORD_BY_ID = "csw?request=GetRecordById&service=CSW&version=2.0.2&elementSetName=full&id=<id>&outputschema=http://www.isotc211.org/2005/gmd";
	private static final String CSW_URL_PARAMETER_SERVICE = "catalog/search/resource/details.page?uuid=<uuid>&title=<title>";
	
	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(CswDocumentProvider.class);
	private final HttpClient client;
	private final String url;
	private final CswXmlParser cswXmlparser;
	private final CkanParser ckanParser;
	private final String encoding;

	private Iterator<String> documents;

	/**
	 * @param client
	 * @param parser
	 * @param url
	 */
	public CswDocumentProvider(HttpClient client, CswXmlParser cswXmlparser, CkanParser ckanParser, String url) {
		this(client, cswXmlparser, ckanParser, url, "UTF-8");
	}

	/**
	 * 
	 * @param client
	 * @param parser
	 * @param url
	 * @param encoding
	 */
	public CswDocumentProvider(HttpClient client, CswXmlParser cswXmlparser, CkanParser ckanParser, String url, String encoding) {
		this.client = client;
		this.url = url;
		this.cswXmlparser = cswXmlparser;
		this.ckanParser = ckanParser;
		this.encoding = encoding;
		documents = fetchXmlList().iterator();

	}

	private List<String> fetchXmlList() {

		log.info("[CswDocumentProvider::fetchXmlList] - START");
		// SAXReader reader = new SAXReader();
		List<String> oggetti = newArrayList();

		try {
			if (System.getProperty("http.proxyHost") != null && System.getProperty("http.proxyPort") != null) {
				client.getHostConfiguration().setProxy(System.getProperty("http.proxyHost"), Integer.parseInt(System.getProperty("http.proxyPort")));
			}
			boolean stopme = false;
			RestTemplate template = new RestTemplate();
			int start = 1;
			int rows = 10;
			//	String getRecordByIdUrl = "http://webgis.arpa.piemonte.it/geoportalserver_arpa/csw?request=GetRecordById&service=CSW&version=2.0.2&elementSetName=full&id=<id>&outputschema=http://www.isotc211.org/2005/gmd";
			//String getRecordByIdUrl = System.getProperty("singleItemeUrl");
			
			String getRecordByIdUrl = url + CSW_URL_PARAMETER_GET_RECORD_BY_ID;


			while (!stopme) {
				String urlList = url + CSW_URL_PARAMETER_GET_LIST;
				String query = urlList.replace("<startposition>", "" + start).replace("<maxrecords>", "" + rows);
				ResponseEntity<String> entity = template.getForEntity(query, String.class);

				String body = entity.getBody();
				// MediaType contentType = entity.getHeaders().getContentType();
				org.springframework.http.HttpStatus statusCode = entity.getStatusCode();

				if (statusCode == org.springframework.http.HttpStatus.OK) {
					GetRecords getRecords = cswXmlparser.getRecords(body);
					if (getRecords != null && getRecords.getResults() != null && getRecords.getResults().numberOfRecordsReturned != null
							&& getRecords.getResults().numberOfRecordsReturned.length() > 0
							&& Integer.parseInt(getRecords.getResults().numberOfRecordsReturned) > 0) {
						List<String> ids = cswXmlparser.getIds(getRecords);
						if (ids != null && ids.size() > 0) {
							for (String id : ids) {
								String queryId = getRecordByIdUrl.replace("<id>", id).replace("{", "%7B").replace("}", "%7D");
								oggetti.add(queryId);
							}
							log.info("[CswDocumentProvider::fetchXmlList] - aggiunti  " + ids.size() + " oggetti");
						}
					} else {
						stopme = true;
					}
				}
				start += rows;

			}

		} catch (Exception e) {
			log.error("[CswDocumentProvider::fetchXmlList] - ERROR: " + e.getMessage());

			throw new RuntimeException("Error while retrieving xml index", e);
		} finally {
			log.info("[CswDocumentProvider::fetchXmlList] - END");
		}
		return oggetti;

	}

	@SuppressWarnings("unused")
	private InputStream aagetXml(String xmlUrl) throws HttpException, IOException {

		log.info("getting url content:: " + xmlUrl);

		HttpMethod method = new GetMethod(xmlUrl);
		int executeMethod;

		executeMethod = client.executeMethod(method);

		if (executeMethod != org.apache.commons.httpclient.HttpStatus.SC_OK)
			throw new IOException("Server response:: " + method.getStatusText());

		InputStream xmlStream = method.getResponseBodyAsStream();
		return xmlStream;

	}

	public boolean hasNext() {
		return documents.hasNext();
	}


	public SolrInputDocument next() {

		String query = documents.next();
		log.info("getting url content:: " + query);
		try {
			
			
			
			HttpHeaders headers = new HttpHeaders();
			headers.setContentType(MediaType.APPLICATION_JSON);
			RestTemplate template = new RestTemplate();
			
			ResponseEntity<String> entity = template.getForEntity(query, String.class);
			
		    String body = entity.getBody();
			HttpStatus statusCode = entity.getStatusCode();

				
			
			
			
			SolrInputDocument doc = null;
			
			if (statusCode==HttpStatus.OK /*&& contentType==MediaType.APPLICATION_JSON*/) {
				
				GetRecordsByIdResponse response = cswXmlparser.getRecordsByIdResponse(body);
				//String serviceUrl = "http://webgis.arpa.piemonte.it/geoportalserver_arpa/catalog/search/resource/details.page?uuid=<uuid>";
				//String serviceUrl = System.getProperty("singleServiceUrl");
				String serviceUrl = url + CSW_URL_PARAMETER_SERVICE;
				String urlServizioComplete = Utils.replaceInBraket(serviceUrl, "uuid", Utils.ltrim(response.getIdFonteDatoSafe(), 50));
				Package pack  = cswXmlparser.toCkan(response, urlServizioComplete);
	
	    		doc = ckanParser.parse(pack, query, encoding);
				if (doc == ERROR_DOC) log.warn("error while parsing doc:: " + query);
			} else {
				log.warn("error while parsing doc:: " + query);
			}

			return doc;

		} catch (Exception e) {
			log.error("error while retrieving doc:: " + query, e);

			//IOUtils.closeQuietly(reader);
		}
		return ERROR_DOC;
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

}
