package it.csi.indexer.util;

import java.util.Map;
import java.util.StringTokenizer;

public class Utils {

	public static int decode(String element, Map<String, Integer> map) {
		return decode(element, map, -1);
	}

	public static int decode(String element, Map<String, Integer> map, int def) {
		if (map.containsKey(element)) {
			return map.get(element).intValue();
		}
		return def;
	}

	public static String ltrim(String s, int length) {
		if (s != null && s.length() > length) {
			return s.substring(0, length - 1);
		}
		return s;
	}

	public static String parseDate(String s) {
		return Utils.parseDate(s, false);
	}

	public static String parseDate(String s, boolean retNull) {
		String result = null;
		if (s != null) {
			switch (s.length()) {
			case 10:
				result = s;
				break;
			case 7:
				result = s + "-01";
				break;
			case 4:
				result = s + "-01-01";
				break;
			default:
				break;
			}
		}

		if (result == null) {
			if (retNull)
				return null;
			return "";
		}
		return result;
	}

	public static String replaceInBraket(String text, String tag, String replacement) {
		if (text == null || tag == null)
			return text;
		return text.replaceAll("<" + tag + ">", replacement == null ? "" : replacement);
	}

	public static String raddoppiaApici(String s) {
		if (s == null)
			return null;
		else if (s.equals(""))
			return "";
		String buffer = "";
		StringTokenizer st = new StringTokenizer(s, "'");
		while (st.hasMoreTokens()) {
			buffer += st.nextToken();
			if (st.hasMoreTokens())
				buffer += "''";
		}

		int last = s.length();
		if (s.substring(last - 1).equals("'"))
			buffer += "''";

		return buffer;
	}

	public static void main(String[] args) {
		// String text = "><vivia<t<tag>";
		// String textToReplace = "nuovo";
		// String tag = "tag";
		// System.out.println(replaceInBraket(text, tag, textToReplace));

		String in = "2011-06";
		System.out.println(in + "->" + Utils.parseDate(in));
	}
}
