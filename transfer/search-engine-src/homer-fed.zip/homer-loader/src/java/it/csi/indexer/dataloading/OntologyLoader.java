package it.csi.indexer.dataloading;

import info.aduna.iteration.Iterations;

import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URI;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import lombok.extern.log4j.Log4j;

import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.common.SolrInputDocument;
import org.openrdf.model.Model;
import org.openrdf.model.Resource;
import org.openrdf.model.Value;
import org.openrdf.model.impl.LinkedHashModel;
import org.openrdf.model.impl.LiteralImpl;
import org.openrdf.model.vocabulary.SKOS;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFParseException;
import org.openrdf.sail.memory.MemoryStore;

import com.google.common.collect.Lists;

/**
 * @author alessio.bosca@celi.it
 */
@Log4j
public class OntologyLoader implements DataLoaderInterface {

	private static final String ontologyFileName = "eurovoc_lite.rdf";
	private final SolrServer srv;

	public OntologyLoader(SolrServer server) {
		srv = server;	
	}

	public void load()  {
		try {
			Repository memoryRepo = new SailRepository(new MemoryStore());
			memoryRepo.initialize();
			RepositoryConnection localCon = memoryRepo.getConnection();
			InputStreamReader reader=new InputStreamReader(this.getClass().getClassLoader().getResourceAsStream(ontologyFileName), "UTF-8");
			localCon.add(reader, "", RDFFormat.RDFXML);
			
			int globalCnt=1;
			// per ogni uri piglia prefLabel e altLabel
			Model model = Iterations.addAll(localCon.getStatements(null, null, null, false), new LinkedHashModel());
			Set<Resource> subjs = new HashSet<Resource>(model.subjects());
			for(Resource res: subjs ){
				try {
					File conceptURI = new File(res.stringValue());
					String conceptName=conceptURI.getName();
					Set<Value> labels = new HashSet<Value>(model.filter(res, SKOS.PREF_LABEL, null).objects());
					labels.addAll(model.filter(res, SKOS.ALT_LABEL, null).objects());
					List<SolrInputDocument> docs=Lists.newArrayList();
					for(Value val: labels){
						try {
							LiteralImpl literal = (LiteralImpl) val;
							String lang = literal.getLanguage();
							String label = literal.getLabel();
							docs.add(indexConceptLabel((globalCnt++),conceptName, label, lang));
						} catch (Exception e) {
							log.error("error while indexing ontology concept:: ", e);
						}
					}
					srv.add(docs);
				} catch (Exception e) {
					log.error("error while calling solr:: ", e);
				}
			}
			srv.commit();
			localCon.close();
			memoryRepo.shutDown();
		} catch (Exception e) {
			log.error("error while loading ontology data:: ", e);
		}
	}
	
	/**
	 * Effettua una cnacellazione di tutti i documenti presenti nel searcher
	 */
	public void clean() {
		try {
			String cleanQuery = "*:*";
			log.info("deleting previous indexed ontology with query:: " + cleanQuery);
			srv.deleteByQuery(cleanQuery);
			log.info("deleted");

		} catch (SolrServerException e) {
			log.error("error while calling solr:: ", e);
		} catch (IOException e) {
			log.error("error while calling solr:: ", e);
		}

	}

	private SolrInputDocument indexConceptLabel(int id, String conceptURI, String label, String lang) {
		SolrInputDocument doc=new SolrInputDocument();
		doc.addField("id", id);
		doc.addField("conceptURI", conceptURI);
		doc.addField("language", lang);
		label=label.replaceAll("\\([^)]+\\)","").trim();
		label=label.replaceAll("^[0-9]+","").trim();
		doc.addField("term", label);
		doc.addField("search_text_"+lang, label);
		return doc;
	}

}
