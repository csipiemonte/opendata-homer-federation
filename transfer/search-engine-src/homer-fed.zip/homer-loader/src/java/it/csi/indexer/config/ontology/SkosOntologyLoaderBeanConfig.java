package it.csi.indexer.config.ontology;

import java.net.MalformedURLException;

import it.csi.indexer.config.dati.DatiPiemonteLoaderBeanConfig;
import it.csi.indexer.dataloading.OntologyLoader;

import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.impl.CommonsHttpSolrServer;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;

/**
 * Configurazione Spring
 * 
 * @author franchini@celi.it
 * @author ventaglio@celi.it
 * @author alessio.bosca@celi.it
 */
@Configuration
@ImportResource("classpath:/META-INF/properties-config.xml")
public class SkosOntologyLoaderBeanConfig {
	
	@Value("${solr.server.url}")
	private String solrServerUrl;

	
	@Bean
	public OntologyLoader ontologyLoader() {
		return new OntologyLoader(solrServer("ontology/"));
	}
	
	private SolrServer solrServer(String core) {
		String solrServerUrl_coreSpecific=solrServerUrl;
		if(!solrServerUrl_coreSpecific.endsWith("/"))
			solrServerUrl_coreSpecific+="/"+core;
		else
			solrServerUrl_coreSpecific+=core;
		
		SolrServer server;
		try {
			server = new CommonsHttpSolrServer(solrServerUrl_coreSpecific);
		} catch (MalformedURLException e) {
			throw new RuntimeException(e);
		}

		return server;
	}

}
