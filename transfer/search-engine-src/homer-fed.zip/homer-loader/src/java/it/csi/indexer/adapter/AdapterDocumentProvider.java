/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.adapter;

import static com.google.common.collect.Lists.newArrayList;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Iterator;
import java.util.List;

import lombok.extern.log4j.Log4j;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpException;
import org.apache.commons.httpclient.HttpMethod;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.io.IOUtils;
import org.apache.solr.common.SolrInputDocument;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

/**
 * Provider di documenti: si aggncia alla url in cui trovare la lista dei
 * documeti da scaricare, scarica i singoli documenti, li parsifica e crea il
 * corrispondente documento SOLR.
 * 
 * @author franchini@celi.it
 * @author ventaglio@celi.it
 */
@Log4j
public class AdapterDocumentProvider implements Iterator<SolrInputDocument> {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(AdapterDocumentProvider.class);
	private final HttpClient client;
	private final String url;
	private final AdapterXmlParser parser;
	private final String encoding;

	private Iterator<String> xmlDocuments;

	/**
	 * @param client
	 * @param parser
	 * @param url
	 */
	public AdapterDocumentProvider(HttpClient client, AdapterXmlParser parser, String url) {
		this(client, parser, url, "UTF-8");
	}

	/**
	 * 
	 * @param client
	 * @param parser
	 * @param url
	 * @param encoding
	 */
	public AdapterDocumentProvider(HttpClient client, AdapterXmlParser parser, String url, String encoding) {
		this.client = client;
		this.url = url;
		this.parser = parser;
		this.encoding = encoding;
		xmlDocuments = fetchXmlList().iterator();

	}

	private List<String> fetchXmlList() {

		SAXReader reader = new SAXReader();
		List<String> oggetti = newArrayList();

		try {
			InputStream xmlStream = getXml(url);

			Document xmlList = reader.read(xmlStream);
			Element urlOggetti = xmlList.getRootElement();
			String baseUrl = urlOggetti.attributeValue("baseUrl");

			Iterator<Element> elementIterator = urlOggetti.elementIterator();
			while (elementIterator.hasNext()) {
				Element oggetto = elementIterator.next();

				String url = baseUrl + oggetto.getStringValue();
				oggetti.add(url);

			}

		} catch (Exception e) {
			throw new RuntimeException("Error while retrieving xml index", e);
		}
		return oggetti;

	}

	private InputStream getXml(String xmlUrl) throws HttpException, IOException {

		log.info("getting url content:: " + xmlUrl);

		HttpMethod method = new GetMethod(xmlUrl);
		int executeMethod;
		log.info("client proxy : "  + client.getHostConfiguration().getProxyPort()+ ":"+client.getHostConfiguration().getProxyPort());

		;
		executeMethod = client.executeMethod(method);

		if (executeMethod != HttpStatus.SC_OK) throw new IOException("Server response:: " + method.getStatusText());

		InputStream xmlStream = method.getResponseBodyAsStream();
		return xmlStream;

	}

	public boolean hasNext() {

		return xmlDocuments.hasNext();
	}


	public SolrInputDocument next() {
		InputStreamReader reader = null;
		String xmlUrl = xmlDocuments.next();
		try {

			InputStream xml = getXml(xmlUrl);

			reader = new InputStreamReader(xml, encoding);

			SolrInputDocument doc = parser.parse(reader, xmlUrl, encoding);

			if (doc == AdapterXmlParser.ERROR_DOC) log.warn("error while parsing doc:: " + xmlUrl);

			return doc;

		} catch (Exception e) {
			log.error("error while retrieving doc:: " + xmlUrl, e);

			IOUtils.closeQuietly(reader);
		}
		return AdapterXmlParser.ERROR_DOC;
	}

	public void remove() {
		throw new UnsupportedOperationException();
	}

}
