/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.dataloading;

import static com.google.common.base.Predicates.in;
import static com.google.common.collect.Collections2.filter;
import static com.google.common.collect.Lists.newArrayList;
import static org.apache.commons.lang3.StringUtils.isNotEmpty;
import static org.apache.commons.lang3.StringUtils.trimToEmpty;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.Reader;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Set;

import lombok.extern.log4j.Log4j;

import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.common.SolrInputField;
import org.apache.solr.common.util.DateUtil;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;

import com.google.common.base.Joiner;

/**
 * Parser dei documenti xml. Effettua il mapping tra un documento XML ed il corrispondente {@link SolrInputDocument}
 * 
 * @author franchini@celi.it
 * @author ventaglio@celi.it
 * 
 */
@Log4j
public class XMLDocumentParser {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(XMLDocumentParser.class);
	public static final SolrInputDocument ERROR_DOC = new SolrInputDocument();

	private final Set<String> dateFieldNames;
	private final Collection<String> contentsFields;
	private final Collection<String> xpaths;
	private String portal;

	/**
	 * @param xpaths
	 *            elenco di espresisoni xpath per la selezione dei nodi dell'xml
	 * @param contentsFields
	 *            elenco di nomi di campi che andranno a formare il campo di default per le ricerche
	 * @param dateFieldsPatten
	 *            espressione regolare che identifica i campi di tipo data
	 */
	public XMLDocumentParser(Collection<String> xpaths, Collection<String> contentsFields, Set<String> dateFieldNames, String portal) {
		super();

		this.xpaths = xpaths;
		this.dateFieldNames = dateFieldNames;
		this.contentsFields = contentsFields;
		this.portal = portal;
	}

	/**
	 * Metodo principale: riceve il file xml da parsificare e crea il corrispondente {@link SolrInputDocument} Non vengono mappati campi vuoti e date mal formate. Nel caso il parser xml vada in eccezione viene restituito un documento di errore.
	 * 
	 * @param xml
	 *            file xml da parsificare
	 * @param encoding
	 *            da usare per parsificare il contenuto
	 * 
	 * @return {@link SolrInputDocument} pronto per l'inserimento o un docuemnto di errore nel caso il parsing abbia riscontrato errori
	 */
	public SolrInputDocument parse(File xml, String encoding) {

		try {

			SolrInputDocument doc = parse(new FileReader(xml), xml.getAbsolutePath(), encoding);

			return doc;

		} catch (FileNotFoundException e) {
			return ERROR_DOC;
		}

	}

	/**
	 * Metodo principale: riceve un {@link Reader} per il documento xml da parsificare e crea il corrispondente {@link SolrInputDocument}. Non vengono mappati campi vuoti e date mal formate. Nel caso il parser xml vada in eccezione viene restituito
	 * un documento di errore.
	 * 
	 * @param xml
	 *            Reader sul documento xml da parsificare
	 * @param origin
	 *            metadato che identifica l'origine del documento
	 * @param encoding
	 *            da usare per parsificare il contenuto
	 * @return {@link SolrInputDocument} pronto per l'inserimento o un docuemnto di errore nel caso il parsing abbia riscontrato errori
	 */

	public SolrInputDocument parse(Reader xml, String origin, String encoding) {
		SAXReader reader = new SAXReader();
		reader.setEncoding(encoding);

		Document document;
		try {
			document = reader.read(xml);
		} catch (DocumentException e) {
			return ERROR_DOC;
		}

		SolrInputDocument doc = new SolrInputDocument();
		doc.addField("metadata_origin", origin);
		doc.addField("portal", portal);

		for (String xpath : xpaths) {

			List<Element> nodes = document.selectNodes(xpath);
			for (Element node : nodes) {

				String text = trimToEmpty(node.getText());
				log.debug("_-_- node: " + node.getName() + " text: " + node.getText());
				if (isNotEmpty(text)) {
					doc.addField(node.getName(), text);
				} else {
					if ("resource".equals(node.getName())) {
						handleResourceElement(node, doc);
					}
				}
			}
			log.debug("___ " + origin);
			for (SolrInputField solrInputField : doc) {
				log.debug("--- field: " + solrInputField.getName() + " firstValue: " + solrInputField.getFirstValue() + " value:  " + solrInputField.getValue());
			}

		}

		handleDateFields(doc);
		createContents(doc);
		return doc;
	}

	private void handleResourceElement(Element resource, SolrInputDocument doc) {

		List<String> resourceElems = newArrayList();

		List<Element> children = resource.elements();
		for (Element child : children) {

			String text = trimToEmpty(child.getText());
			if (isNotEmpty(text)) {
				doc.addField("resource_" + child.getName(), text);
				resourceElems.add(child.getName() + '=' + child.getText());
			}
		}

		doc.addField("resource", Joiner.on("||").join(resourceElems));
	}

	/**
	 * Crea il campo su cui verranno effettuate le ricerche sul {@link SolrInputDocument}
	 * 
	 * @param doc
	 *            il {@link SolrInputDocument} da manipolare
	 */
	private void createContents(SolrInputDocument doc) {
		Collection<String> contents = filter(doc.getFieldNames(), in(contentsFields));

		StringBuilder text = new StringBuilder();
		for (String contentPart : contents) {
			text.append(doc.getField(contentPart).getValue()).append(' ');
		}

		doc.addField("contents_text", text.toString());
	}

	/**
	 * Manipola i campi data all'inderno del {@link SolrInputDocument} eliminando i campi mal formati. Eventuali errori di parsing vengono loggati.
	 * 
	 * @param doc
	 *            il {@link SolrInputDocument} da manipolare
	 */
	private void handleDateFields(SolrInputDocument doc) {
		Collection<String> dateFields = new ArrayList<String>(filter(doc.getFieldNames(), in(dateFieldNames)));

		for (String name : dateFields) {
			SolrInputField field = doc.getField(name);
			String value = (String) field.getValue();
			doc.remove(name);
			try {

				Date date = DateUtil.parseDate(value);
				doc.addField(name, date);

			} catch (ParseException e) {

				log.error("unable to parse date field:: " + name + " :: " + value + " on document:: " + doc.getFieldValue("metadata_origin"));
			}
		}
	}
}
