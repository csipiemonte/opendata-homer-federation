/*
 * PSI loader - A set of script, libraries and utilities to load and index
 * data in the PSI searcher and indexer.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.adapter;

import it.csi.indexer.dataloading.DataLoaderInterface;

import java.io.IOException;
import java.util.List;

import lombok.extern.log4j.Log4j;

import org.apache.solr.client.solrj.SolrServer;
import org.apache.solr.client.solrj.SolrServerException;
import org.apache.solr.common.SolrInputDocument;

import static com.google.common.collect.Lists.newLinkedList;

/**
 * @author franchini@celi.it
 * @author ventaglio@celi.it
 * 
 */
@Log4j
public class AdapterLoader implements DataLoaderInterface {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(AdapterLoader.class);
	private final SolrServer server;
	private final int commitBatchSize;
	private final AdapterDocumentProvider provider;
	private final String cleanQuery, idSource;

	/**
	 * @param server
	 * @param provider
	 */
//	public AdapterLoader(SolrServer server, AdapterDocumentProvider provider) {
//		this(server, provider, "*:*");
//	}

	/**
	 * @param server
	 * @param provider
	 */
	public AdapterLoader(SolrServer server, AdapterDocumentProvider provider,String idSource,  String cleanQuery) {

		super();
		this.server = server;
		this.provider = provider;
		this.commitBatchSize = 100;
		this.idSource = idSource;
		this.cleanQuery = cleanQuery;
	}

	/**
	 * Effettua una cnacellazione di tutti i documenti presenti nel searcher
	 */
	public void clean() {
		try {
			log.info("deleting previous indexed documents with query:: " + cleanQuery);
			server.deleteByQuery(cleanQuery);
			log.info("deleted");

		} catch (SolrServerException e) {
			log.error("error while calling solr:: ", e);
		} catch (IOException e) {
			log.error("error while calling solr:: ", e);
		}

	}

	/**
	 * Effettua il caricamento dei documenti.
	 * 
	 */
	public void load() {

		List<SolrInputDocument> docs = newLinkedList();

		while (provider.hasNext()) {
			SolrInputDocument doc = provider.next();
			doc.addField("sourceID", this.idSource);

			if (doc.equals(AdapterXmlParser.ERROR_DOC)) log.error("Skipping error document");

			else docs.add(doc);

			if (docs.size() >= commitBatchSize) {
				insertAndCommit(docs);
				docs.clear();
			}
		}

		insertAndCommit(docs);

	}

	private void insertAndCommit(List<SolrInputDocument> docs) {
		log.info("documents to be indexed:: " + docs.size());
		try {
			server.add(docs);
			server.commit();
		} catch (SolrServerException e) {
			log.error("error while calling solr:: ", e);
		} catch (IOException e) {
			log.error("error while calling solr:: ", e);
		}

	}

}
