package it.csi.indexer.dataloading;

/*
 * Common interface for documents loaders
 */
public interface DataLoaderInterface {

	public void load();
	public void clean();
	
}
