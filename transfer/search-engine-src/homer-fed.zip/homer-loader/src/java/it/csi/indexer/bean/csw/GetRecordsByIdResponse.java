/*
 *  PSI apisrv - A set of API to harvest and federate Open Data 
 * engines via CKAN dialect.
 *
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.indexer.bean.csw;


import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

@XmlRootElement(name = "GetRecordByIdResponse", namespace = "http://www.opengis.net/cat/csw/2.0.2")
public class GetRecordsByIdResponse {

	private static Logger log = Logger.getLogger(GetRecordsByIdResponse.class);
	// protected static transient Log log =
	// LogFactory.getLog(GetRecordsByIdResponse.class);

	@XmlElement(name = "MD_Metadata", namespace = "http://www.isotc211.org/2005/gmd")
	private MDMetadata element = new MDMetadata();

	public MDMetadata getElement() {
		return element;
	}

	public String getIdSafe() {
		try {
			return getElement().getFileIdentifier().getId();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getTitleSafe() {
		try {
			return getElement().getIdentificationInfo().getMdDataIdentification().getCitation().getCiCitation().getTitle().getValue();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getTipoDatoFormSafe() {
		try {
			return getElement().getIdentificationInfo().getMdDataIdentification().getCitation().getCiCitation().getPresentationForm().getValue();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getDescriptionSafe() {
		try {
			return getElement().getIdentificationInfo().getMdDataIdentification().getDescription().getValue();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getIdFonteDatoSafe() {
		try {
			return getElement().getFileIdentifier().getId();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}
	
	public String getLanguageSafe(){
		try {
			return getElement().getLanguage().getLanguageCode();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public List<String> getKeywordsSafe() {
		List<String> result = new ArrayList<String>();
		try {
			if (getElement() != null && getElement().getIdentificationInfo() != null && getElement().getIdentificationInfo().getMdDataIdentification() != null
					&& getElement().getIdentificationInfo().getMdDataIdentification().getDescriptiveKeywords() != null) {
				for (DescriptiveKeywords descriptiveKeywords : getElement().getIdentificationInfo().getMdDataIdentification().getDescriptiveKeywords()) {
					if (descriptiveKeywords != null && descriptiveKeywords.getMdKeywords() != null && descriptiveKeywords.getMdKeywords().getKeyword() != null) {
						for (Keyword element : descriptiveKeywords.getMdKeywords().getKeyword()) {
							if (element != null && element.getValue() != null) {
								result.add(element.getValue());
							}
						}
					}
				}
			}
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
		}
		return result;
	}

	// gmd:distributionInfo><gmd:MD_Distribution><gmd:distributionFormat><gmd:MD_Format><gmd:name><gco:CharacterString>shp</gco:CharacterString></gmd:name>

	public String getFormatsSafe() {
		String result = "";
		try {
			if (getElement() != null && getElement().getDistributionInfo() != null && getElement().getDistributionInfo().getMdDistribution() != null
					&& getElement().getDistributionInfo().getMdDistribution().getDistributionFormat() != null
					&& getElement().getDistributionInfo().getMdDistribution().getDistributionFormat().getMdFormat() != null
					&& getElement().getDistributionInfo().getMdDistribution().getDistributionFormat().getMdFormat().getName() != null
					&& getElement().getDistributionInfo().getMdDistribution().getDistributionFormat().getMdFormat().getName().getValue() != null) {

				result = getElement().getDistributionInfo().getMdDistribution().getDistributionFormat().getMdFormat().getName().getValue();

			}
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
		}
		return result;
	}

	public List<OnLine> getOnlineListSafe() {
		try {
			return getElement().getDistributionInfo().getMdDistribution().getTransferOptions().getMdDigitalTransferOptions().getOnLine();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return new ArrayList<OnLine>();
		}
	}

	public String getLicenseUrlSafe() {
		String result = null;
		if (getElement() != null && getElement().getIdentificationInfo() != null && getElement().getIdentificationInfo().getMdDataIdentification() != null
				&& getElement().getIdentificationInfo().getMdDataIdentification().getResourceConstraints() != null) {
			for (ResourceConstraints rc : getElement().getIdentificationInfo().getMdDataIdentification().getResourceConstraints()) {
				if (rc.getMDLegalConstraints() != null && rc.getMDLegalConstraints().getOtherConstraints() != null
						&& rc.getMDLegalConstraints().getOtherConstraints().getValue() != null) {
					String urlEstesa = rc.getMDLegalConstraints().getOtherConstraints().getValue();
					int indexHttp = urlEstesa.lastIndexOf("http");
					if (indexHttp > -1) {
						if (urlEstesa.indexOf(" ", indexHttp) > -1)
							result = urlEstesa.substring(indexHttp, urlEstesa.indexOf(" ", indexHttp));
						else
							result = urlEstesa.substring(indexHttp);

					}
				}

			}
		}

		return result;
	}

	// public static void main(String[] args) {
	// String result = null;
	//
	// String urlEstesa =
	// "http://webgis.arpa.piemonte.it/w-metadoc/Download/Carta_Litologica_100k_licenzaCC25BY.pdf  http://ciao";
	// int indexHttp = urlEstesa.lastIndexOf("http");
	// System.out.println(indexHttp);
	// System.out.println(urlEstesa.indexOf(" ", indexHttp));
	// if (indexHttp > -1) {
	// if (urlEstesa.indexOf(" ", indexHttp) > -1)
	// result = urlEstesa.substring(indexHttp, urlEstesa.indexOf(" ",
	// indexHttp));
	// else
	// result = urlEstesa.substring(indexHttp);
	//
	// }
	// System.out.println(result);
	// }

	// public List<String> getUrlSafe() {
	// List<String> result = new ArrayList<String>();
	// try {
	// for (OnLine onLine : getOnlineListSafe()) {
	// result.add(onLine.getCiOnlineResource().getLinkage().getURL());
	// }
	//
	// } catch (Exception e) {
	// log.error(e);e.printStackTrace();
	//
	// }
	// return result;
	// }

	public String getScalaSafe() {
		try {
			return ""
					+ getElement().getIdentificationInfo().getMdDataIdentification().getSpatialResolution().getMdResolution().getEquivalentScale()
							.getMdRepresentativeFraction().getDenominator().getValue().intValue();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getReferenceSystemSafe() {
		try {
			return getElement().getReferenceSystemInfo().getMdReferenceSystem().getReferenceSystemIdentifier().getRsIdentifier().getCode().getValue();
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getCreationDateSafe() {
		try {
			for (Date date : getElement().getIdentificationInfo().getMdDataIdentification().getCitation().getCiCitation().getDates()) {
				if (date.getCiDate().getDateType().getValue().equals("creation")) {
					return date.getCiDate().getDate().getValue();
				}
			}
			return "";
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getRevisionDateSafe() {
		try {
			for (Date date : getElement().getIdentificationInfo().getMdDataIdentification().getCitation().getCiCitation().getDates()) {
				if (date.getCiDate().getDateType().getValue().equals("revision")) {
					return date.getCiDate().getDate().getValue();
				}
			}
			return "";
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getDateStampSafe() {
		try {
			if (getElement().getDateStamp() != null && getElement().getDateStamp().getValue() != null) {
				return getElement().getDateStamp().getValue();
			}
			return "";
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public String getOwnerSafe() {
		String ownerSafe = "";
		try {
			for (CitedResponsibleParty element : getElement().getIdentificationInfo().getMdDataIdentification().getCitation().getCiCitation()
					.getCitedResponsibleParty()) {
				if (element != null && element.getCiResponsibleParty() != null && element.getCiResponsibleParty().getRole() != null
						&& element.getCiResponsibleParty().getRole().getValue() != null && element.getCiResponsibleParty().getRole().getValue().equals("owner")) {
					if (element.getCiResponsibleParty().getOrganisationName() != null
							&& element.getCiResponsibleParty().getOrganisationName().getValue() != null) {
						ownerSafe= element.getCiResponsibleParty().getOrganisationName().getValue();
					}
				}
			}
			
			if(ownerSafe==null || ownerSafe.trim().equals(""))
				ownerSafe  =""; //FIXME da correggere!
			return ownerSafe;
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return "";
		}
	}

	public List<String> getTopicsSafe() {
		List<String> result = new ArrayList<String>();
		try {
			for (TopicCategory element : getElement().getIdentificationInfo().getMdDataIdentification().getTopicCategory()) {
				if (element != null && element.getValues() != null) {
					for (String value : element.getValues()) {
						result.add(value);
					}
				}
			}
			return result;
		} catch (Exception e) {
			log.error(e);e.printStackTrace();
			return result;
		}
	}

	public String getFrequenzaAggiornamentoSafe() {
		return getElement().getIdentificationInfo().getMdDataIdentification().getResourceMaintenance().getMDMaintenanceInformation()
				.getMaintenanceAndUpdateFrequency().getValue();
	}

}
