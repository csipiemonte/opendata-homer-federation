#!/bin/bash
clear
start=`date +%s`
echo "*************************************************************"
echo "*                                                           *"
echo "*   procedura di indicizzazione portale Opendata Piemonte   *"
echo "*                                                           *"
echo "*************************************************************"

portals_config_url=@wrapper.sh-csv.url@	
echo "lettura da url $portals_config_url"

rows=$(curl -s $portals_config_url)
echo "lettura ok"
 
is_header_row=true

for row in $rows
do
	if [[ $row == "#"* ]];then
		echo "Riga da non eseguire: $row"
	else
		IFS=','; arr=($row)

		if $is_header_row ;then
			echo ""
			echo "FORMATO DEL CSV"
			is_header_row=false
			counter=0
			for w in "${arr[@]}"
			do
				echo "$counter - $w"
				counter=$((counter+1))
			done
			echo ""
			echo ""
		else
			# FORMATO DEL CSV
			# 0 - Portal
			# 1 - Source_ID
			# 2 - Federation_Type
			# 3 - Base_Url
			# 4 - Sorl_Server_Url
			# 5 - Clean_Query
			# 6 - Package_Prefix
			# 7 - Language
			# 8 - sourceUrlPrefix
			if [ "${#arr[@]}" -gt 1 ]; then
				echo "--- ROW ---  $row"
				echo "PORTAL ${arr[0]}"
				echo "Source ${arr[1]}"
				echo "Federation_Type ${arr[2]}"
				echo "Base_Url ${arr[3]}"
				echo "Sorl_Server_Url ${arr[4]}"
				echo "Clean_Query ${arr[5]}"
				echo "Package_Prefix ${arr[6]}"
				echo "Language ${arr[7]}"
				cmd="@wrapper.sh-home.path@run.sh -DbaseUrl=${arr[3]} -Dhttp.proxyHost=proxy-srv.csi.it -Dhttp.proxyPort=3128 -DcleanQuery=${arr[5]} -Dfederation.type=${arr[2]} -Dsolr.server.url=${arr[4]} -DsourceID=${arr[1]} -Dportal=${arr[0]} -Dpackage.prefix=${arr[6]} -Dpackage.language=${arr[7]} -Dsource.url.prefix=${arr[8]}  "
				echo "esecuzione del comando $cmd"  
				eval $cmd
				echo ""  			
				echo ""  			
				echo ""  			
			fi
		fi
	fi
done
end=`date +%s`
runtime=$((end-start))
echo "performing reclassify..."
wget -q "@wrapper.sh-solr.server.url@/select/?q=*:*&reclassify=true" --spider 
echo "FINE DELL'ELABORAZIONE - Tempo impiegato: $runtime secondi"
	

