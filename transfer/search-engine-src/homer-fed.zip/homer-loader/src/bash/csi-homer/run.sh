#!/bin/bash
# java home

export JAVA_HOME=@run.sh-java_home@
echo "Java Home is $JAVA_HOME"

# properties di sistema
for a in `seq 1 $#`
do
  eval current_param="$"{$a}
  PROPERTIES="$PROPERTIES $current_param"
done

#home dir dell'analisi: default dir corrente 
analysis_home=@run.sh-analysis_home@

PROPERTIES="$PROPERTIES -Danalysis.working.dir=$analysis_home/working"

cd $analysis_home

#build directory
mkdir -p @run.sh-log_directory@
mkdir -p @run.sh-source_directory@
 
MAIN="it.csi.indexer.Main"

JVM_OPTS=" -Djava.awt.headless=true \
		-Xmx1024M  \
		-XX:+UseParallelOldGC -XX:+UseParallelGC \
		-XX:+DisableExplicitGC  \
		-XX:+DoEscapeAnalysis \
		-XX:+AggressiveOpts \
		-XX:+PrintGCDetails -XX:+PrintGCDateStamps \
		-XX:+PrintCommandLineFlags \
		-XX:-UseConcMarkSweepGC -XX:+CMSClassUnloadingEnabled "

add_to_classpath(){
        JARS=`ls $1/*.jar`
        for JAR in $JARS
        do
                CLASSPATH=$CLASSPATH:$JAR
        done
}

add_to_classpath "$analysis_home/lib/"

CMD="@run.sh-java_cmd@ $JVM_OPTS -cp $CLASSPATH $PROPERTIES $MAIN "

echo "executing: $CMD"

nohup $CMD >> @run.sh-log_file@ #&

