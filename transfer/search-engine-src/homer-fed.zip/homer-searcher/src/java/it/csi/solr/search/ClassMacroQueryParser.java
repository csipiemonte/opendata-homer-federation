/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.search;

import it.csi.solr.handler.component.classification.ClassificationAwareSearchComponent;
import it.csi.solr.handler.component.classification.ClassificationResolver;
import it.csi.utils.Jsonized;

import java.util.Map;

import org.apache.lucene.analysis.Analyzer;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.Query;
import org.apache.solr.schema.IndexSchema;
import org.apache.solr.search.DocSet;
import org.apache.solr.search.QParser;
import org.apache.solr.search.SolrConstantScoreQuery;
import org.apache.solr.search.SolrQueryParser;

public class ClassMacroQueryParser extends SolrQueryParser {

	public final static String CLASS_FIELD = "_classid";

	public ClassMacroQueryParser(IndexSchema schema, String defaultField) {
		super(schema, defaultField);
	}

	public ClassMacroQueryParser(QParser parser, String defaultField) {
		super(parser, defaultField);
	}

	public ClassMacroQueryParser(QParser parser, String defaultField, Analyzer analyzer) {
		super(parser, defaultField, analyzer);
	}

	@SuppressWarnings("unchecked")
	@Override
	protected Query getFieldQuery(String field, String queryText, boolean quoted) throws ParseException {

		if (CLASS_FIELD.equals(field)) {

			String facetId = queryText;

			Map<String, Jsonized> classification = (Map<String, Jsonized>) parser.getReq().getContext().get(ClassificationAwareSearchComponent.CLASS_REQ_KEY);
			if (classification != null) {
				DocSet docSet;
				try {
					docSet = new ClassificationResolver().resolve(classification.get(facetId), parser.getReq());
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
				return new SolrConstantScoreQuery(docSet.getTopFilter());
			}
		}

		return super.getFieldQuery(field, queryText, quoted);
	}

}
