/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification;

import it.csi.utils.Jsonized;

import java.io.IOException;
import java.util.Map;

import org.apache.lucene.queryParser.ParseException;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.common.util.SimpleOrderedMap;
import org.apache.solr.handler.component.ResponseBuilder;
import org.apache.solr.search.DocSet;

public class FacetingClassificationComponent extends ClassificationAwareSearchComponent {

	private static final String PARAM_NAME = "classid";

	@Override
	public void prepare(Map<String, Jsonized> classification, ResponseBuilder rb) throws IOException {
		super.prepare(classification, rb);

		String[] params = rb.req.getParams().getParams(PARAM_NAME);
		if (params != null && params.length > 0) {
			rb.setNeedDocSet(true);
		}
	}

	@Override
	public void process(ResponseBuilder rb) throws IOException {
		String param = rb.req.getParams().get(PARAM_NAME);
		if (param == null) return;

		String[] params = param.split(",");

		NamedList<Integer> res = new SimpleOrderedMap<Integer>();

		Map<String, Jsonized> classification = getClassification(rb);
		for (String classId : params) {
			Jsonized jsonClass = classification.get(classId);
			if (jsonClass != null) {
				int docCount;
				try {
					DocSet docSet = new ClassificationResolver().resolve(jsonClass, rb.req);
					docCount = docSet.intersection(rb.getResults().docSet).size();
				} catch (ParseException e) {
					docCount = -1;
				}
				res.add(classId, Integer.valueOf(docCount));
			}
		}

		rb.rsp.add("classification_counts", res);
	}

}
