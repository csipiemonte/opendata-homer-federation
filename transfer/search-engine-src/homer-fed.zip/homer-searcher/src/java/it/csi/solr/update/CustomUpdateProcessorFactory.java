package it.csi.solr.update;

import it.csi.onto.OntologyLabelMatcher;
import it.csi.utils.Iso639;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.apache.solr.common.SolrInputDocument;
import org.apache.solr.core.SolrCore;
import org.apache.solr.request.SolrQueryRequest;
import org.apache.solr.response.SolrQueryResponse;
import org.apache.solr.update.AddUpdateCommand;
import org.apache.solr.update.processor.UpdateRequestProcessor;
import org.apache.solr.update.processor.UpdateRequestProcessorFactory;

public class CustomUpdateProcessorFactory extends UpdateRequestProcessorFactory {
	public static final String ConceptField = "concept";
	
	@Override
	public UpdateRequestProcessor getInstance(SolrQueryRequest req, SolrQueryResponse rsp, UpdateRequestProcessor next) {
		SolrCore ontoCore=req.getCore().getCoreDescriptor().getCoreContainer().getCore("ontology");
		return new CustomUpdateProcessor(next, ontoCore);
	}
}

class CustomUpdateProcessor extends UpdateRequestProcessor {
	private OntologyLabelMatcher labelMatcher;
	private SolrCore ontoCore;

	public CustomUpdateProcessor(UpdateRequestProcessor next, SolrCore ontoCore) {
		super(next);
		this.labelMatcher = new OntologyLabelMatcher(); 
		this.ontoCore = ontoCore;
	}

	@Override
	public void processAdd(AddUpdateCommand cmd) throws IOException {
		SolrInputDocument doc = cmd.getSolrInputDocument();
		
		String lang=null;
		//Moving contents to language specific field - if the language field is present in the document
		String contents=(String)doc.getFieldValue("contents_text");
		if (contents!=null && doc.getFieldNames().contains("language")) {
			lang = doc.getField("language").getValue().toString();
			Iso639 langCode = Iso639.find(lang);
			if(langCode!=null){
				lang=langCode.twoCharCode.toLowerCase();
				doc.addField("contents_text_" + lang, contents);
				
				//Concept references from tags
				Collection<Object> tagCollection = doc.getFieldValues("tag");
				if(tagCollection!=null){
					for(Object tagObj: tagCollection){
						String tag = (String) tagObj;
						Set<String> exactMatch = this.labelMatcher.getMatchingConceptsURI(ontoCore, tag, lang);
						for(String uri: exactMatch){
							doc.addField(CustomUpdateProcessorFactory.ConceptField,uri);
						}
					}
				}
				
				//Concept References in contents
				Set<String> exactMatch = this.labelMatcher.getMatchingConceptsURI(ontoCore, contents, lang);
				for(String uri: exactMatch){
					doc.addField(CustomUpdateProcessorFactory.ConceptField,uri,0.5f);
				}
			}
		}
		// pass it up the chain
		super.processAdd(cmd);
	}
}
