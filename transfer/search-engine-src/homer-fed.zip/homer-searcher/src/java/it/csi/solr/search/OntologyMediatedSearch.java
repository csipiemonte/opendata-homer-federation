package it.csi.solr.search;

import it.csi.onto.GraphBuilder;
import it.csi.onto.HashedGraph;
import it.csi.onto.OntoFilterProvider;
import it.csi.onto.OntologyLabelMatcher;
import it.csi.solr.update.CustomUpdateProcessorFactory;

import java.io.IOException;
import java.util.Set;

import org.apache.solr.client.solrj.util.ClientUtils;
import org.apache.solr.common.params.CommonParams;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.core.SolrCore;
import org.apache.solr.request.SolrQueryRequest;
import org.apache.solr.response.SolrQueryResponse;

import com.google.common.collect.Sets;


public class OntologyMediatedSearch extends org.apache.solr.handler.component.SearchHandler {

	private static final String LanguageParam = "lang", ContentsFieldsPrefix="contents_text_";
	public OntologyLabelMatcher labelMatcher;
	public HashedGraph tree;

	public OntologyMediatedSearch(){
		this.labelMatcher = new OntologyLabelMatcher(); 
		try {
			GraphBuilder builder = new GraphBuilder(OntoFilterProvider.DOMAINS);
			builder.initializeGraph();
			this.tree = builder.getHashedGraph();
		} catch (Exception e) {
			System.err.println("Could not load hashedGraph component "+e);
		}
	}


	@Override
	public void handleRequest(SolrQueryRequest req, SolrQueryResponse resp) {
		try {
			SolrParams params = req.getParams();
			String query = params.get(CommonParams.Q);
			String lang = params.get(OntologyMediatedSearch.LanguageParam);
			if(lang!=null && lang.length()>0 && !query.contains(":") && this.labelMatcher!=null){
				SolrCore ontoCore=req.getCore().getCoreDescriptor().getCoreContainer().getCore("ontology");
				String newQuery = this.composeSemanticQuery(query, lang, ontoCore);			
				req.setParams(this.createNewParams(newQuery, params));
			}			
		} catch (Exception e) {
			e.printStackTrace();
		}
		super.handleRequest(req, resp);
	}

	public String composeSemanticQuery(String query, String lang, SolrCore ontoCore) throws IOException {
		String newQuery=ContentsFieldsPrefix+lang+":("+ClientUtils.escapeQueryChars(query)+") ";

		Set<String> matchedConcepts = this.labelMatcher.getMatchingConceptsURI(ontoCore, query, lang);
		Set<String> concepts4Query=Sets.newHashSet();
		if(matchedConcepts.size()>0){
			StringBuilder builder=new StringBuilder();
			for(String uri: matchedConcepts){
				if(this.tree!=null){
					concepts4Query.addAll( tree.getSubTreeUris(uri) );
				}
				else concepts4Query.add(uri);
			}
			for(String childURI: concepts4Query){
				builder.append(ClientUtils.escapeQueryChars(childURI)).append(" ");
			}
			newQuery+=CustomUpdateProcessorFactory.ConceptField+":("+builder.toString().trim()+")^10 ";
		}
		System.out.println(">> NQ: "+newQuery);
		return newQuery;
	}


	private SolrParams createNewParams(String newQuery, SolrParams params) {
		NamedList<Object> nlParams = params.toNamedList();
		nlParams.remove(CommonParams.Q);
		nlParams.add(CommonParams.Q, newQuery);
		return SolrParams.toSolrParams(nlParams);
	}


}
