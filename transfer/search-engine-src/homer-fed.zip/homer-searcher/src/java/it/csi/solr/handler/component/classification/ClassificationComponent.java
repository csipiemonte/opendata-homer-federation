/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification;

import it.csi.solr.handler.component.NoSolrInfoMBeanComponent;
import it.csi.solr.handler.component.classification.loader.ClassificationLoader;
import it.csi.utils.Jsonized;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.handler.component.ResponseBuilder;
import org.apache.solr.handler.component.SearchComponent;

public class ClassificationComponent extends NoSolrInfoMBeanComponent {

	private final List<ClassificationAwareSearchComponent> subComponents;
	private final ClassificationLoader classificationLoader;

	public ClassificationComponent(ClassificationLoader classificationLoader, List<ClassificationAwareSearchComponent> subComponents) {
		this.classificationLoader = classificationLoader;
		this.subComponents = subComponents;
	}

	@Override
	public void init(NamedList args) {
		super.init(args);

		for (SearchComponent wc : subComponents) {
			wc.init(args);
		}
	}

	@Override
	public void prepare(ResponseBuilder rb) throws IOException {
		SolrParams params = rb.req.getParams();

		if (params.getBool("reclassify", false)) {
			classificationLoader.reload(params);
		}

		Map<String, Jsonized> classification = classificationLoader.load(params);

		for (ClassificationAwareSearchComponent wc : subComponents) {
			wc.prepare(classification, rb);
		}
	}

	@Override
	public void process(ResponseBuilder rb) throws IOException {
		for (SearchComponent wc : subComponents) {
			wc.process(rb);
		}
	}
}
