package it.csi.onto;

import static org.junit.Assert.assertTrue;
import it.csi.solr.search.OntologyMediatedSearch;
import it.csi.solr.update.CustomUpdateProcessorFactory;

import java.io.IOException;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.xml.parsers.ParserConfigurationException;

import org.apache.lucene.document.Document;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.ScoreDoc;
import org.apache.lucene.search.TopDocs;
import org.apache.solr.client.solrj.util.ClientUtils;
import org.apache.solr.core.CoreContainer;
import org.apache.solr.core.SolrCore;
import org.apache.solr.search.QueryParsing;
import org.apache.solr.search.SolrIndexSearcher;
import org.xml.sax.SAXException;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;


public class OntologyLabelMatcher {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(OntologyLabelMatcher.class);

	private static final String SearchFieldPrefix = "search_text_";
	

	public Set<String> getMatchingConceptsURI(SolrCore ontoCore, String query, String lang) throws IOException {
		Map<String,String> exactMatch = Maps.newHashMap();

		log.error("[OntologyLabelMatcher::getMatchingConceptsURI] query: " + query);

		SolrIndexSearcher ontoSearcher = ontoCore.getSearcher().get();
		String q = OntologyLabelMatcher.SearchFieldPrefix + lang + ":(" + ClientUtils.escapeQueryChars(query) + ")";
		Query parsedQuery = QueryParsing.parseQuery(q, ontoSearcher.getSchema());
		String stemmedQuery = parsedQuery.toString().replaceAll(OntologyLabelMatcher.SearchFieldPrefix + lang + ":", "");
		String lookupStemmedQuery = " " + stemmedQuery.toLowerCase() + " ";
		log.error("[OntologyLabelMatcher::getMatchingConceptsURI] lookupStemmedQuery: " + lookupStemmedQuery);
		
		TopDocs resultDocs = ontoSearcher.search(parsedQuery, 500);
		for(ScoreDoc sdoc : resultDocs.scoreDocs) {
			Document doc = ontoSearcher.doc(sdoc.doc);
			String cUri = doc.get("conceptURI");
			String term = doc.get("term");

			Query parsedLabel = QueryParsing.parseQuery(OntologyLabelMatcher.SearchFieldPrefix + lang + ":(" + ClientUtils.escapeQueryChars(term) + ")", ontoSearcher.getSchema());
			String stemmedLabel = parsedLabel.toString().replaceAll(OntologyLabelMatcher.SearchFieldPrefix + lang + ":", "");
			String lookupStemmedLabel = " " + stemmedLabel.toLowerCase() + " ";

			log.error("[OntologyLabelMatcher::getMatchingConceptsURI] lookupStemmedLabel: " + lookupStemmedLabel);
			if(lookupStemmedQuery.contains(lookupStemmedLabel)){
				boolean toAdd = true;
				Set<String> toRemove = new HashSet<String>();
				for(String storedStemmedLab : exactMatch.keySet()){
					String lookupStoredStemmedLab = " " + storedStemmedLab + " ";
					log.error("[OntologyLabelMatcher::getMatchingConceptsURI] lookupStoredStemmedLab: " + lookupStoredStemmedLab);

					if(lookupStoredStemmedLab.contains(lookupStemmedLabel))
						toAdd = false;
					else if(lookupStemmedLabel.contains(lookupStoredStemmedLab)){
						toRemove.add(storedStemmedLab);
					}
				}
				for(String key: toRemove){
					exactMatch.remove(key);
				}
				if(toAdd){
					exactMatch.put(stemmedLabel, cUri);
				}
			}
		}

		return Sets.newHashSet(exactMatch.values());
	}

}
