package it.csi.onto;

import org.apache.commons.lang3.StringUtils;

import com.google.common.collect.ImmutableSet;

public class OntoFilterProvider {

	public static final String EUROVOC_NAMESPACE = "http://eurovoc.europa.eu/";
	
	public static final ImmutableSet<String> DOMAINS = ImmutableSet.of(
			"http://eurovoc.europa.eu/100156", // 56
			"http://eurovoc.europa.eu/100150", // 32 -> escludere "3206 istruzione","3226 comunicazione", "3231 informazione ed elaborazione dell'informazione", "3236 informatica e trattamento dei dati"
			"http://eurovoc.europa.eu/100149", // 28 -> escludere "2806 famiglia", "2816 demografia e popolazione", "2821 quadro sociale", "2836 protezione sociale", "2841 salute", "2846 urbanistica e edilizia", "2811 migrazione"
			"http://eurovoc.europa.eu/100159", // 66
			"http://eurovoc.europa.eu/100155" // 52
			);

	public static final ImmutableSet<String> BLACKSET = ImmutableSet.of(
			"http://eurovoc.europa.eu/100217", // 3206 istruzione
			"http://eurovoc.europa.eu/100221", // 3226 comunicazione
			"http://eurovoc.europa.eu/100222", // 3231 informazione ed elaborazione dell'informazione
			"http://eurovoc.europa.eu/100223", // 3236 informatica e trattamento dei dati
			"http://eurovoc.europa.eu/100208", // 2806 famiglia
			"http://eurovoc.europa.eu/100210", // 2816 demografia e popolazione
			"http://eurovoc.europa.eu/100211", // 2821 quadro sociale
			"http://eurovoc.europa.eu/100214", // 2836 protezione sociale
			"http://eurovoc.europa.eu/100215", // 2841 salute
			"http://eurovoc.europa.eu/100216", // 2846 urbanistica e edilizia
			"http://eurovoc.europa.eu/100209" // 2811 migrazione
			);
	
	public static final String notinString = "(<"+ StringUtils.join(BLACKSET, ">, <") + ">)";
}
