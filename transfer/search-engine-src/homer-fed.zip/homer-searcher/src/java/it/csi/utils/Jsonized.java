package it.csi.utils;


import java.util.Date;
import java.util.List;
import java.util.Map;

import org.joda.time.DateTime;

import com.google.common.collect.Lists;

public class Jsonized {

	private final Map<String, Object> map;

	public Jsonized(Map<String, Object> map) {
		this.map = map;
	}
	
	public boolean isEmpty() {
		return map.isEmpty();
	}

	public Boolean b(String key) {
		return (Boolean) map.get(key);
	}

	public Double d(String key) {
		return (Double) map.get(key);
	}

	public DateTime dt(String key) {
		return (DateTime) map.get(key);
	}

	public Date date(String key) {
		return (Date) map.get(key);
	}

	@SuppressWarnings("unchecked")
	public <T> T get(String key) {
		return (T) map.get(key);
	}

	public boolean has(String key) {
		return map.containsKey(key);
	}

	public Integer i(String key) {
		return (Integer) map.get(key);
	}

	@SuppressWarnings("unchecked")
	public Jsonized j(String key) {
		if (!has(key)) {
			throw new RuntimeException(key + " doesn't contain any value");
		}
		Object object = map.get(key);
		if (!(object instanceof Map<?, ?>)) {
			throw new RuntimeException(object + " is not jsonizable");
		}
		return new Jsonized((Map<String, Object>) object);
	}

	public Long l(String key) {
		return (Long) map.get(key);
	}

	public List<?> list(String key) {
		return (List<?>) map.get(key);
	}

	@SuppressWarnings("unchecked")
	public <T> List<T> tList(String key) {
		return (List<T>) map.get(key);
	}

	@SuppressWarnings("unchecked")
	public List<Jsonized> jlist(String key) {
		List<Jsonized> result = Lists.newLinkedList();
		for (Object child : list(key)) {
			if (!(child instanceof Map<?, ?>)) {
				throw new IllegalArgumentException("Key " + key + " is not a list of Maps. Offending element: " + child);
			}
			result.add(new Jsonized((Map<String, Object>) child));
		}
		return result;
	}

	public Map<String, Object> raw() {
		return map;
	}

	public void add(String key, Object value) {
		raw().put(key, value);
	}

	public String s(String key) {
		return (String) map.get(key);
	}

	@Override
	public String toString() {
		return "Jsonized: " + map.toString();
	}
}

