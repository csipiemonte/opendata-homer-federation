/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.config;

import it.csi.solr.handler.component.WonderWheelComponent;
import it.csi.solr.handler.component.classification.ClassificationAwareSearchComponent;
import it.csi.solr.handler.component.classification.ClassificationComponent;
import it.csi.solr.handler.component.classification.FacetChildrenClassificationComponent;
import it.csi.solr.handler.component.classification.FacetTreesClassificationComponent;
import it.csi.solr.handler.component.classification.FacetingClassificationComponent;
import it.csi.solr.handler.component.classification.FilteringClassificationComponent;
import it.csi.solr.handler.component.classification.loader.ClassificationLoader;
import it.csi.solr.handler.component.classification.loader.MultiClassificationLoader;

import java.util.List;

import org.apache.solr.handler.component.SearchComponent;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.google.common.collect.Lists;

@Configuration
public class Config {

	@Value("${url.classification}")
	private String classificationUrl;

	@Bean
	public ClassificationLoader classificationLoader() {

		return new MultiClassificationLoader(classificationUrl);

	}

	@Bean
	public SearchComponent classificationComponent() {
		List<ClassificationAwareSearchComponent> components = Lists.newLinkedList();
		components.add(new FacetingClassificationComponent());
		components.add(new FilteringClassificationComponent());
		components.add(new FacetChildrenClassificationComponent());
		components.add(new FacetTreesClassificationComponent());

		return new ClassificationComponent(classificationLoader(), components);
	}

	@Bean
	public SearchComponent wonderWheelComponent() {
		return new WonderWheelComponent();
	}

}
