/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification;

import static com.google.common.collect.Lists.newLinkedList;
import static com.google.common.collect.Maps.newHashMap;
import static com.google.common.collect.Sets.newHashSet;
import static it.csi.solr.handler.component.classification.FilteringClassificationComponent.FACET_FILTER_PARAM;
import static java.util.Arrays.asList;
import it.csi.utils.Jsonized;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.handler.component.ResponseBuilder;
import org.apache.solr.search.DocSet;

public class FacetTreesClassificationComponent extends ClassificationAwareSearchComponent {

	public static final String CHILD_SEP = "|";

	private static final String PARAM_NAME = "ft";

	@Override
	public void prepare(Map<String, Jsonized> classification, ResponseBuilder rb) throws IOException {
		super.prepare(classification, rb);

		String[] params = rb.req.getParams().getParams(PARAM_NAME);
		if (params != null && params.length > 0) {
			rb.setNeedDocSet(true);
		}
	}

	@Override
	public void process(ResponseBuilder rb) throws IOException {

		SolrParams solrParams = rb.req.getParams();

		String param = solrParams.get(PARAM_NAME);
		if (param == null) return;

		String[] params = param.split(",");

		Map<String, Jsonized> classification = getClassification(rb);
		DocSet searchDocSet = rb.getResults().docSet;

		Set<String> selectedFacets = extractSelectedFacets(solrParams);

		List<Map<String, Object>> trees = newLinkedList();
		for (String classId : params) {
			Jsonized jsonClass = classification.get(classId);
			if (jsonClass!=null) {
				trees.add(createTreeElement(jsonClass, searchDocSet, rb, selectedFacets));
			}
		}

		trees.addAll(convertSolrFacetToTrees(rb, selectedFacets));

		rb.rsp.add("classification_trees", trees);
	}

	private Set<String> extractSelectedFacets(SolrParams solrParams) {

		Set<String> selectedFacets = newHashSet();

		String param = solrParams.get(FACET_FILTER_PARAM);
		if (param==null) return selectedFacets;

		String[] filters = param.split(",");
		if (filters!=null) {
			selectedFacets.addAll(asList(filters));
		}

		return selectedFacets;
	}

	private Map<String, Object> createTreeElement(Jsonized jsonClass, DocSet searchDocSet, ResponseBuilder rb, Set<String> selectedFacets) {

		String facetId = jsonClass.s("name");
		Map<String, Object> elem = createFacet(facetId, jsonClass.s("description"), Integer.valueOf(calculateDocCount(jsonClass, searchDocSet, rb)), selectedFacets);

		List<Jsonized> jsonChildren = jsonClass.jlist("children");
		if (jsonChildren == null || jsonChildren.isEmpty()) return elem;

		List<Map<String, Object>> children = newLinkedList();
		for (Jsonized jsonChild : jsonChildren) {
			children.add(createTreeElement(jsonChild, searchDocSet, rb, selectedFacets));
		}
		elem.put("children", children);

		return elem;
	}

	private int calculateDocCount(Jsonized jsonClass, DocSet searchDocSet, ResponseBuilder rb) {
		try {
			DocSet docSet = new ClassificationResolver().resolve(jsonClass, rb.req);
			return docSet.intersection(searchDocSet).size();
		} catch (Exception e) {
			return -1;
		}
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	private List<Map<String, Object>> convertSolrFacetToTrees(ResponseBuilder rb, Set<String> selectedFacets) {

		List<Map<String, Object>> facetTrees = newLinkedList();

		NamedList solrValues = rb.rsp.getValues();
		NamedList facetCounts = (NamedList) solrValues.get("facet_counts");
		if (facetCounts==null) return facetTrees;

		NamedList facetFields = (NamedList) facetCounts.get("facet_fields");
		if (facetCounts==null) return facetTrees;

		Iterator itTrees = facetFields.iterator();
		while (itTrees.hasNext()) {
			Entry<String, NamedList> facetField = (Entry<String, NamedList>) itTrees.next();
			String rootId = facetField.getKey();
			Map<String, Object> root = createFacet(rootId, rootId, Integer.valueOf(-1), selectedFacets);

			List<Map<String, Object>> children = newLinkedList();
			NamedList solrFacetChildren = facetField.getValue();

			for (int i = 0; i < solrFacetChildren.size(); i++) {
				String facetName = solrFacetChildren.getName(i);
				String facetId = rootId + CHILD_SEP + facetName;
				Map<String, Object> facet = createFacet(facetId, facetName, solrFacetChildren.getVal(i), selectedFacets);
				children.add(facet);
			}
			root.put("children", children);
			facetTrees.add(root);
		}

		facetCounts.remove("facet_fields");

		return facetTrees;
	}

	private Map<String, Object> createFacet(String facetId, String descr, Object count, Set<String> selectedFacets) {

		Map<String, Object> facet = newHashMap();
		facet.put("id", facetId);
		facet.put("description", descr);
		facet.put("count", count);
		facet.put("isSelected", Boolean.valueOf(selectedFacets.contains(facetId)));

		return facet;
	}
}
