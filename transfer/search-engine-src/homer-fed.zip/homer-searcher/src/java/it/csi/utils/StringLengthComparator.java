package it.csi.utils;

import java.util.Comparator;

public class StringLengthComparator implements Comparator<String>{

	public int compare(String arg0, String arg1) {
		if(arg0.length() != arg1.length()){
			return (arg0.length() - arg1.length()) ;
		}
		else
			return arg0.compareTo(arg1);
	}

}
