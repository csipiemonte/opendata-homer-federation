package it.csi.onto;

import info.aduna.iteration.Iterations;
import it.csi.model.Element;
import it.csi.model.Elements;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Set;

import org.openrdf.model.Model;
import org.openrdf.model.Resource;
import org.openrdf.model.Value;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.LinkedHashModel;
import org.openrdf.model.impl.LiteralImpl;
import org.openrdf.model.vocabulary.SKOS;
import org.openrdf.repository.Repository;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFParseException;
import org.openrdf.sail.memory.MemoryStore;

import com.google.common.collect.Lists;
import com.thoughtworks.xstream.XStream;

public class GraphBuilder {

	private Set<String> rootSet;
	private Model model;
	private Repository memoryRepo;
	private RepositoryConnection localCon;
	private ValueFactory factory;
	private HashedGraph hashedGraph = new HashedGraph();
	private Elements elements;

	public GraphBuilder (Set<String> rootSet) throws RepositoryException, RDFParseException, IOException {
		this.rootSet = rootSet;
		this.memoryRepo = new SailRepository(new MemoryStore());
		memoryRepo.initialize();
		this.localCon = memoryRepo.getConnection();
		InputStream file = this.getClass().getClassLoader().getResourceAsStream(OntologyExtractor.ontologyFileName);
		this.localCon.add(file, "", RDFFormat.RDFXML);
		this.model = Iterations.addAll(localCon.getStatements(null, null, null, false), new LinkedHashModel());
		this.factory = localCon.getValueFactory();
	}

	public void initializeGraph() throws Exception {
		ArrayList<Element> elementList = Lists.newArrayList();
		this.elements = new Elements(elementList);
		for(String domain : rootSet) {
			Set<Value> prefLabels = model.filter(factory.createURI(domain), SKOS.PREF_LABEL, null).objects();
			String name = getLabelWithLanguage(prefLabels, "en");
			Element el = exploreTree(new Element(domain.replace(OntoFilterProvider.EUROVOC_NAMESPACE, ""), name));
			elementList.add(el);
		}
	}

	private void close() throws RepositoryException {
		this.localCon.close();
		this.memoryRepo.shutDown();
	}

	private String getLabelWithLanguage(Set<Value> values, String langTag) throws Exception {
		for(Value v : values) {
			LiteralImpl label = (LiteralImpl)v;
			if(label.getLanguage().equals(langTag))
				return label.stringValue();
		}
		throw new Exception("Nessuna prefLabel con tag " + langTag);
	}

	private Element exploreTree(Element el) throws Exception {
		hashedGraph.put(el.getId(), el);
		Set<Resource> children = model.filter(null, SKOS.BROADER, factory.createURI(OntoFilterProvider.EUROVOC_NAMESPACE + el.getId())).subjects();
		for(Resource child : children) {
			//if(!blackSet.contains(child.stringValue())) {
			Set<Value> childNames = model.filter(child, SKOS.PREF_LABEL, null).objects();
			String childName = getLabelWithLanguage(childNames, "en");
			el.addChild(exploreTree(new Element(child.stringValue().replace(OntoFilterProvider.EUROVOC_NAMESPACE, ""), childName)));
			//}
		}
		return el;
	}

	public Elements getElements() {
		return this.elements;
	}

	public HashedGraph getHashedGraph() {
		return this.hashedGraph;
	}

	public String getXml() {
		XStream stream = new XStream();
		stream.processAnnotations(Element.class);
		stream.processAnnotations(Elements.class);
		return stream.toXML(this.elements);
	}

	public static void main(String... args) throws Exception {
		GraphBuilder builder = new GraphBuilder(OntoFilterProvider.DOMAINS);
		builder.initializeGraph();
		System.out.println(builder.getXml());
		builder.close();
	}
}
