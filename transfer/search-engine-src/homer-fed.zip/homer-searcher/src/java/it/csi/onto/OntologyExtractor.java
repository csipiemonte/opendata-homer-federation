package it.csi.onto;

import info.aduna.iteration.Iterations;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Properties;
import java.util.Set;

import org.openrdf.model.Model;
import org.openrdf.model.Resource;
import org.openrdf.model.ValueFactory;
import org.openrdf.model.impl.LinkedHashModel;
import org.openrdf.model.vocabulary.RDF;
import org.openrdf.model.vocabulary.SKOS;
import org.openrdf.query.GraphQuery;
import org.openrdf.query.GraphQueryResult;
import org.openrdf.query.MalformedQueryException;
import org.openrdf.query.QueryEvaluationException;
import org.openrdf.query.QueryLanguage;
import org.openrdf.repository.RepositoryConnection;
import org.openrdf.repository.RepositoryException;
import org.openrdf.repository.sail.SailRepository;
import org.openrdf.repository.sparql.SPARQLRepository;
import org.openrdf.rio.RDFFormat;
import org.openrdf.rio.RDFHandlerException;
import org.openrdf.rio.RDFParseException;
import org.openrdf.rio.RDFWriter;
import org.openrdf.rio.Rio;
import org.openrdf.rio.UnsupportedRDFormatException;
import org.openrdf.sail.memory.MemoryStore;

import com.google.common.collect.Sets;

public class OntologyExtractor {

	private String endpoint;
	private RepositoryConnection remoteCon;
	private GraphQuery query;
	private RepositoryConnection localCon;
	private ValueFactory factory;
	private Properties props;
	private SPARQLRepository remoteRepo;
	private SailRepository memoryRepo;
	private static String domainsAltLabelsFile = "src/main/resources/domainsAltLabels.rdf";
	public static final String ontologyFileName = "eurovoc_lite.rdf", queriesPropertiesFilename = "queries.properties";

	public OntologyExtractor(String endpoint) {
		this.endpoint = endpoint;
	}

	public void initialize() throws IOException, RepositoryException, MalformedQueryException {
		remoteRepo = new SPARQLRepository(endpoint);
		remoteRepo.initialize();
		memoryRepo = new SailRepository(new MemoryStore());
		memoryRepo.initialize();
		localCon = memoryRepo.getConnection();
		remoteCon = remoteRepo.getConnection();
		factory = remoteRepo.getValueFactory();
		props = new Properties();
		props.load(OntologyExtractor.class.getClassLoader().getResourceAsStream(queriesPropertiesFilename));
		String queryString = props.getProperty("construct_query").toString();
		queryString = queryString.replace("?notinString", OntoFilterProvider.notinString);
		query = remoteCon.prepareGraphQuery(QueryLanguage.SPARQL, queryString);
	}

	public void extractRDF(GraphQuery query) throws QueryEvaluationException, RepositoryException, MalformedQueryException, RDFParseException, IOException {
		makeConstruct();
		addLabels();
	}

	private void makeConstruct() throws QueryEvaluationException, RepositoryException {
		for(String domain : OntoFilterProvider.DOMAINS) {
			query.setBinding("domain", factory.createURI(domain));
			System.out.println(query);
			GraphQueryResult result = query.evaluate();
			localCon.add(result);
		}
	}

	private void addLabels() throws RepositoryException, MalformedQueryException, QueryEvaluationException, RDFParseException, IOException {
		Model model = Iterations.addAll(localCon.getStatements(null, null, null, false), new LinkedHashModel());
		GraphQuery labelsQuery = remoteCon.prepareGraphQuery(QueryLanguage.SPARQL, props.getProperty("labels_query").toString());
		Set<Resource> resources = Sets.newHashSet();
		resources.addAll(model.filter(null, RDF.TYPE, SKOS.CONCEPT).subjects());
		resources.addAll(model.filter(null, RDF.TYPE, SKOS.CONCEPT_SCHEME).subjects());
		for(Resource res : resources) {
			labelsQuery.setBinding("concept", factory.createURI(res.stringValue()));
			localCon.add(labelsQuery.evaluate());
		}
		localCon.add(new File(domainsAltLabelsFile), "", RDFFormat.RDFXML);
	}

	public void close() throws RepositoryException {
		localCon.close();
		memoryRepo.shutDown();
		remoteCon.close();
		remoteRepo.shutDown();
	}

	public static void main(String[] args) throws RepositoryException, MalformedQueryException, QueryEvaluationException, UnsupportedRDFormatException, RDFHandlerException, IOException, RDFParseException {

		OntologyExtractor extractor = new OntologyExtractor("http://tersite.celi.it:8080/openrdf-sesame/repositories/nativeStore");
		extractor.initialize();
		extractor.extractRDF(extractor.query);

		RDFWriter writer = Rio.createWriter(RDFFormat.RDFXML, new FileOutputStream(new File(ontologyFileName)));
		extractor.localCon.export(writer);

		extractor.close();
	}
}
