/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification.loader;

import it.csi.solr.handler.component.classification.ClassificationUtils;
import it.csi.utils.Jsonized;

import java.io.File;
import java.util.List;
import java.util.Map;

import org.apache.solr.common.params.SolrParams;
import org.apache.solr.core.SolrResourceLoader;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.annotate.JsonSerialize.Inclusion;

import com.google.common.collect.Maps;

public class JsonFileClassificationLoader extends AbstractClassificationLoader {

	private final String filename;

	public JsonFileClassificationLoader(String filename) {
		this.filename = filename;
	}

	@Override
	protected Map<String, Jsonized> reloadClassification(SolrParams params) {
		ObjectMapper objectMapper = new ObjectMapper();
		objectMapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.INDENT_OUTPUT, true);
		objectMapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.WRITE_DATES_AS_TIMESTAMPS, true);
		objectMapper.configure(org.codehaus.jackson.map.SerializationConfig.Feature.WRAP_ROOT_VALUE, false);
		objectMapper.getSerializationConfig().setSerializationInclusion(Inclusion.NON_NULL);
		objectMapper.getSerializationConfig().set(org.codehaus.jackson.map.SerializationConfig.Feature.FAIL_ON_EMPTY_BEANS, false);
		objectMapper.getDeserializationConfig().set(org.codehaus.jackson.map.DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		File classificationFile;
			if(params==null)
				classificationFile=new File(filename);
			else
				classificationFile= new File(SolrResourceLoader.locateSolrHome(), filename);

		Map<String, Jsonized> classification = Maps.newHashMap();

		Jsonized hierarchy;
		try {
			hierarchy = new Jsonized(objectMapper.readValue(classificationFile, Map.class));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		List<Jsonized> roots = hierarchy.jlist("hierarchy");
		flattenClassification(roots, classification);

		return classification;
	}

	private void flattenClassification(List<Jsonized> elements, Map<String, Jsonized> classification) {
		for (Jsonized element : elements) {
			classification.put(element.s("name"), element);
			if (ClassificationUtils.hasChildren(element)) {
				flattenClassification(element.jlist("children"), classification);
			}
		}
	}

}
