/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification.loader;

import it.csi.utils.Jsonized;

import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import org.apache.solr.common.params.SolrParams;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import au.com.bytecode.opencsv.CSVReader;
import static com.google.common.collect.Maps.newHashMap;


public class MultiClassificationLoader extends AbstractClassificationLoader {

	private static final org.apache.log4j.Logger log = org.apache.log4j.Logger.getLogger(MultiClassificationLoader.class);
	private static final int TREE_ID = 0;
	private static final int ROOT_ID = 1;
	private static final int ELEMENT_ID = 2;
	private static final int URL = 3;

	private final String csvUrl;

	public MultiClassificationLoader(String csvUrl) {
		this.csvUrl = csvUrl;
	}

	@Override
	protected Map<String, Jsonized> reloadClassification(SolrParams params) {

		Map<String, Jsonized> classification = newHashMap();

		InputStreamReader inputStream;
		try {
			DefaultResourceLoader loader = new DefaultResourceLoader();

			log.info("reloading classification list from:: " + csvUrl);
			Resource resource = loader.getResource(csvUrl);

			inputStream = new InputStreamReader(resource.getInputStream(), "UTF-8");

			CSVReader csvReader = new CSVReader(inputStream, ';');

			List<String[]> classificationDefs = csvReader.readAll();

			for (String[] classDef : classificationDefs) {
				String treeId = classDef[TREE_ID];
				String rootId = classDef[ROOT_ID];
				String elementId = classDef[ELEMENT_ID];
				String url = classDef[URL];

				log.info("reloading classification from:: " + url);
				XmlFilesClassificationLoader xmlLoader = new XmlFilesClassificationLoader(url, rootId, elementId, treeId);

				classification.putAll(xmlLoader.load(params));
			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		}

		log.info("classification reloaded - classification size:: " + classification.size());
		return classification;
	}
}
