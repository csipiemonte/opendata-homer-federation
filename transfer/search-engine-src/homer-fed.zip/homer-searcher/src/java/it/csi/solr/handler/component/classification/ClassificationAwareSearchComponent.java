/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification;


import it.csi.solr.handler.component.NoSolrInfoMBeanComponent;
import it.csi.utils.Jsonized;

import java.io.IOException;
import java.util.Map;

import org.apache.solr.handler.component.ResponseBuilder;

public abstract class ClassificationAwareSearchComponent extends NoSolrInfoMBeanComponent {

	public static final String CLASS_REQ_KEY = "classification";

	public void prepare(Map<String, Jsonized> classification, ResponseBuilder rb) throws IOException {
		rb.req.getContext().put(CLASS_REQ_KEY, classification);
	}

	@Override
	public void prepare(ResponseBuilder rb) throws IOException {
		throw new UnsupportedOperationException("Use the method with the classification arg");
	}

	@SuppressWarnings("unchecked")
	public Map<String, Jsonized> getClassification(ResponseBuilder rb) {
		return (Map<String, Jsonized>) rb.req.getContext().get(CLASS_REQ_KEY);
	}

}
