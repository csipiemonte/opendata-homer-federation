package it.csi.onto;

import it.csi.model.Element;

import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import com.google.common.collect.Maps;
import com.google.common.collect.Sets;

public class HashedGraph {

	private Map<String, Element> graph = Maps.newHashMap();

	public Map<String, Element> getGraph() {
		return this.graph;
	}

	public HashedGraph() {
	}

	public void put(String uri, Element el) {
		this.graph.put(uri, el);
	}

	public Set<String> getSubTreeUris(String uri) {
		Element el = this.graph.get(uri);
		Set<String> uris = collectUris(el, Sets.<String>newHashSet());
		return uris;
	}

	private Set<String> collectUris(Element el, HashSet<String> uris) {
		uris.add(el.getId());
		for(Element childEl : el.getChildren()) {
			collectUris(childEl, uris);
		}
		return uris;
	}
}