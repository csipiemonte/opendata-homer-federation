/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.lucene.document.Document;
import org.apache.lucene.index.Term;
import org.apache.lucene.search.TermQuery;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.common.util.NamedList;
import org.apache.solr.handler.component.ResponseBuilder;
import org.apache.solr.search.DocIterator;
import org.apache.solr.search.DocList;
import org.apache.solr.search.SolrIndexSearcher;

import com.google.common.collect.HashMultimap;
import com.google.common.collect.Multimap;
import com.google.common.collect.TreeMultimap;

import static java.util.Collections.reverseOrder;
import static com.google.common.collect.Lists.newLinkedList;
import static com.google.common.collect.Maps.newHashMap;
import static com.google.common.collect.Ordering.natural;

public class WonderWheelComponent extends NoSolrInfoMBeanComponent {

	private static final String PARAM_NAME = "ww";
	private static final String REL_DOC_ID_FN = "package_id";
	private static final String REL_DOC_URL_FN = "url";

	private String relationField;

	@Override
	public void init(NamedList args) {
		super.init(args);

		relationField = args.get("relationField").toString();
	}

	@Override
	public void prepare(ResponseBuilder rb) throws IOException {
		SolrParams params = rb.req.getParams();

		if (params.getBool(PARAM_NAME, false)) rb.setNeedDocList(true);
	}

	@Override
	public void process(ResponseBuilder rb) throws IOException {
		SolrParams params = rb.req.getParams();
		if (!params.getBool(PARAM_NAME, false)) return;

		DocList docList = rb.getResults().docList;
		if (docList.size() < 1) return;

		SolrIndexSearcher searcher = rb.req.getSearcher();
		int docId = docList.iterator().nextDoc();
		Document doc = searcher.doc(docId);

		rb.rsp.add("wonderwheel", extractRelations(docId, doc, searcher));
	}

	private List<Map<String, Object>> extractRelations(int docId, Document doc, SolrIndexSearcher searcher) throws IOException {

		Multimap<Integer, String> allRelatedDocs = extractAllRelatedDocs(docId, doc, searcher);

		List<Integer> sortedRelatedDocs = sortRelatedDocsByNumberOfRelations(allRelatedDocs);

		return extractRelatedDocsData(sortedRelatedDocs, searcher);
	}

	private Multimap<Integer, String> extractAllRelatedDocs(int docId, Document doc, SolrIndexSearcher searcher) throws IOException {

		Multimap<Integer, String> allRelatedDocs = HashMultimap.create();

		Term relTerm = new Term(relationField);
		String[] fieldValues = doc.getValues(relationField);
		for (String val : fieldValues) {
			DocIterator relDocsIt = searcher.getDocSet(new TermQuery(relTerm.createTerm(val))).iterator();
			while (relDocsIt.hasNext()) {
				Integer nextDocId = relDocsIt.next();
				if (nextDocId.intValue() != docId) allRelatedDocs.put(nextDocId, val);
			}
		}

		return allRelatedDocs;
	}

	private List<Integer> sortRelatedDocsByNumberOfRelations(Multimap<Integer, String> allRelatedDocs) {

		List<Integer> sortedRelatedDocs = newLinkedList();

		Multimap<Integer, Integer> groupByNumberOfRelations = TreeMultimap.create(reverseOrder(), natural());
		for (Integer relDoc : allRelatedDocs.keySet()) {
			groupByNumberOfRelations.put(new Integer(allRelatedDocs.get(relDoc).size()), relDoc);
		}

		for (Integer numRelations : groupByNumberOfRelations.keySet()) {
			sortedRelatedDocs.addAll(groupByNumberOfRelations.get(numRelations));
		}

		return sortedRelatedDocs;
	}

	private List<Map<String, Object>> extractRelatedDocsData(List<Integer> sortedRelatedDocs, SolrIndexSearcher searcher) throws IOException {
		List<Map<String, Object>> res = newLinkedList();

		for (Integer relDocId : sortedRelatedDocs) {
			Document relDoc = searcher.doc(relDocId.intValue());

			Map<String, Object> relDocData = newHashMap();
			relDocData.put(REL_DOC_ID_FN, relDoc.get(REL_DOC_ID_FN));
			relDocData.put(REL_DOC_URL_FN, relDoc.get(REL_DOC_URL_FN));
			relDocData.put(relationField, relDoc.getValues(relationField));

			res.add(relDocData);
		}

		return res;
	}

}
