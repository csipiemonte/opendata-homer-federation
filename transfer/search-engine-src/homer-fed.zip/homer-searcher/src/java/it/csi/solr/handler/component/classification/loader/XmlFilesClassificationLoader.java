/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification.loader;

import it.csi.model.Element;
import it.csi.model.Elements;
import it.csi.utils.Jsonized;

import java.io.InputStreamReader;
import java.util.List;
import java.util.Map;

import org.apache.solr.common.params.SolrParams;
import org.springframework.core.io.DefaultResourceLoader;
import org.springframework.core.io.Resource;

import com.google.common.collect.Maps;
import com.thoughtworks.xstream.XStream;

import static it.csi.solr.handler.component.classification.FacetTreesClassificationComponent.CHILD_SEP;
import static it.csi.solr.search.ClassMacroQueryParser.CLASS_FIELD;
import static com.google.common.collect.Lists.newLinkedList;
import static com.google.common.collect.Maps.newHashMap;

public class XmlFilesClassificationLoader extends AbstractClassificationLoader {

	private final String filename;
	private final String treeId;
	private final String elementName;

	private final XStream xstream;

	private String encoding = "UTF-8";

	public XmlFilesClassificationLoader(String filename, String rootName, String elementName) {
		this(filename, rootName, elementName, rootName);
	}

	public XmlFilesClassificationLoader(String filename, String rootName, String elementName, String treeId) {
		this.filename = filename;
		this.treeId = treeId;
		this.elementName = elementName;

		xstream = new XStream();
		xstream.alias(rootName, Elements.class);
		xstream.addImplicitCollection(Elements.class, "elements");

		xstream.alias(elementName, Element.class);
		xstream.useAttributeFor(Element.class, "id");
		xstream.useAttributeFor(Element.class, "name");
		xstream.aliasField("nome", Element.class, "name");
		xstream.addImplicitCollection(Element.class, "children");
	}

	@Override
	protected Map<String, Jsonized> reloadClassification(SolrParams params) {
		InputStreamReader inputStream;
		try {
			DefaultResourceLoader loader = new DefaultResourceLoader();

			Resource resource = loader.getResource(filename);
			inputStream = new InputStreamReader(resource.getInputStream(), encoding);
			Elements elements = (Elements) xstream.fromXML(inputStream);

			return jsonize(elements);

		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	private Map<String, Jsonized> jsonize(Elements elements) {

		Map<String, Jsonized> classification = Maps.newHashMap();

		Map<String, Object> rootMap = newHashMap();
		rootMap.put("name", treeId);
		rootMap.put("description", treeId);
		List<Map<String, Object>> children = jsonizeElements(elements.getElements(), classification);
		rootMap.put("children", children);
		classification.put(treeId, new Jsonized(rootMap));

		return classification;
	}

	private List<Map<String, Object>> jsonizeElements(List<Element> elements, Map<String, Jsonized> classification) {

		List<Map<String, Object>> jsonizedList = newLinkedList();
		if (elements == null) return jsonizedList;

		for (Element elem : elements) {
			Map<String, Object> elemMap = newHashMap();

			String id = treeId + CHILD_SEP + elem.getId();
			elemMap.put("name", id);
			elemMap.put("description", elem.getName());

			List<Map<String, Object>> children = jsonizeElements(elem.getChildren(), classification);
			elemMap.put("children", children);

			elemMap.put("query", createQuery(elem.getId(), elem.getChildren()));

			jsonizedList.add(elemMap);

			classification.put(id, new Jsonized(elemMap));
		}

		return jsonizedList;
	}

	private String createQuery(String id, List<Element> list) {

		StringBuilder sb = new StringBuilder();

		sb.append('(');
		sb.append(elementName).append(':').append(id).append(' ');

		for (Element child : list) {
			sb.append("OR ")
					.append(CLASS_FIELD)
					.append(':')
					.append(treeId)
					.append(CHILD_SEP)
					.append(child.getId())
					.append(' ');
		}
		sb.append(')');

		return sb.toString();
	}

}
