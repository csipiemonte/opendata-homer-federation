/*
 * PSI searcher and indexer - A wrapper implementation of Apache Solr
 * to search and index data.
 * 
 * Copyright (C) 2008 Regione Piemonte
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2,
 * or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 *
 */
package it.csi.solr.handler.component.classification;

import static com.google.common.collect.Lists.newArrayList;
import static it.csi.solr.handler.component.classification.FacetTreesClassificationComponent.CHILD_SEP;
import static org.apache.commons.lang3.StringUtils.isEmpty;
import static org.apache.commons.lang3.StringUtils.substringAfter;
import static org.apache.commons.lang3.StringUtils.substringBefore;
import it.csi.utils.Jsonized;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.lucene.index.Term;
import org.apache.lucene.queryParser.ParseException;
import org.apache.lucene.search.BooleanClause.Occur;
import org.apache.lucene.search.BooleanQuery;
import org.apache.lucene.search.Query;
import org.apache.lucene.search.TermQuery;
import org.apache.solr.common.params.SolrParams;
import org.apache.solr.handler.component.ResponseBuilder;
import org.apache.solr.search.QParser;

public class FilteringClassificationComponent extends ClassificationAwareSearchComponent {

	public enum FacetOperator {
		AND(Occur.MUST), OR(Occur.SHOULD);

		private final Occur operator;

		FacetOperator(Occur operator) {
			this.operator = operator;
		}

		public Occur operator() {
			return operator;
		}
	}

	public static final String FACET_FILTER_PARAM = "ff";
	public static final String FACET_FILTER_OP_PARAM = "fop";

	private final Occur defaultOperator;

	public FilteringClassificationComponent() {
		this(Occur.MUST);
	}

	public FilteringClassificationComponent(Occur defaultOperator) {
		this.defaultOperator = defaultOperator;
	}

	@Override
	public void prepare(Map<String, Jsonized> classification, ResponseBuilder rb) throws IOException {

		SolrParams solrParams = rb.req.getParams();
		String param = solrParams.get(FACET_FILTER_PARAM);
		if (param==null) return;

		String[] params = param.split(",");

		if (rb.getFilters()==null) {
			List<Query> filters = newArrayList();
			rb.setFilters(filters);
		}

		Occur operator = extractOperator(solrParams);

		BooleanQuery facetFilter = new BooleanQuery();

		for (String classId : params) {

			Jsonized jsonClass = classification.get(classId);

			if (jsonClass==null) addQueryFromSolrFacet(classId, operator, facetFilter);
			else addQueryFromCustomClass(rb, classId, jsonClass, operator, facetFilter);
		}

		rb.getFilters().add(facetFilter);

	}

	private Occur extractOperator(SolrParams solrParams) {

		String operator = solrParams.get(FACET_FILTER_OP_PARAM);
		if (isEmpty(operator)) return defaultOperator;

		try {
			return FacetOperator.valueOf(operator).operator();
		} catch (Exception e) {
			return defaultOperator;
		}

	}

	private void addQueryFromSolrFacet(String classId, Occur operator, BooleanQuery facetFilter) {

		String fieldName = substringBefore(classId, CHILD_SEP);
		String fieldValue = substringAfter(classId, CHILD_SEP);
		if (isEmpty(fieldName) || isEmpty(fieldValue)) return;

		Query query = new TermQuery(new Term(fieldName, fieldValue));
		facetFilter.add(query, operator);
	}

	private void addQueryFromCustomClass(ResponseBuilder rb, String classId, Jsonized jsonClass, Occur operator, BooleanQuery facetFilter) throws IOException {
		try {
			Query query = QParser.getParser(jsonClass.s("query"), "classMacro", rb.req).getQuery();
			facetFilter.add(query, operator);
		} catch (ParseException e) {
			throw new IOException("unable to parse query:: " + classId, e);
		}
	}

}
