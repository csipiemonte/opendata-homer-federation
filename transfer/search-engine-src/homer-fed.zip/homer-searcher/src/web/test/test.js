
var URL_FSE = "@test.html-baseUrl@/documents/select/?&fop=OR&wt=json&q=";

var languages = {
		"el":"ελληνικά",
		"en":"English",
		"es":"Españoles",
		"fr":"Français",
		"it":"Italiano",
		"sl":"Slovenski",
		"sr":"Српски"
};


var docs;

var start = 0;
var rowsInPage = 10;
var resultSize = 0;


function init(){
	var inputLangSelect = $("#inputLangSelect");
	var outputLangSelect = $("#outputLangSelect");
	inputLangSelect.append(" <option></option>");
	outputLangSelect.append(" <option></option>");
	$.each(languages, function(value, label) {
		inputLangSelect.append(" <option value='"+value+"'>"+label+"</option>");
		outputLangSelect.append(" <option value='"+value+"'>"+label+"</option>");
	});

	$("#searchSubmit").click(function() {goToPage(0)});
	$(".scrollResultList").click(function() {scroolTo("resultListPanel")});
	$(".scrollSearchInput").click(function() {scroolTo("searchInputPanel")});
	searchInput
}

function search(){
	clear();
	var searchedText = $("#inputSearchText").val();
	var inputLang = $("#inputLangSelect").val();
	var outputLang = $("#outputLangSelect").val();

	//if(searchedText == "")
	//	searchedText = "*.*";
	
	console.debug("testo: " + searchedText);
	console.debug("input lang: " + inputLang);
	console.debug("output lang: " + outputLang);
	var action = URL_FSE + encodeURIComponent(searchedText);
	if(inputLang != "")
		action += "&lang=" + inputLang;
	console.debug("action: " + action);
	if(outputLang != "")
		action += "&fq=language%3A" + outputLang;
	
	start = $("#paginationStart").text();
	action +="&start="+start+"&rows="+rowsInPage;
	
	$("#searchUrl").text(action);
	$("#searchUrl").attr("href",action);
	
	

	$.ajax({ dataType: "json",url: action}).done(function( data ) {
			console.log( "Found: ", data.response.numFound);
			$("#responseQTime").text(data.responseHeader.QTime);
			$("#responseNumFound").text(data.response.numFound);
			$("#paginationStart").text(start+rowsInPage);
			resultSize = data.response.numFound;
			
			var nPages = parseInt(numPages());
			var cPage = parseInt(currentPage());
			var counter = parseInt(1 + (cPage-1)*rowsInPage);
			
			var tbody = "";
			docs = data.response.docs;
			if(docs.length==0){
				$("#info-message-panel").show();
			}
			$.each(data.response.docs, function(index, doc) {
				//console.log(doc);
				
				var languageIcon = formatLangIcon("sq", doc.language);
				tbody += "<tr><td>" +counter+"</td><td>" + doc.package_id + "</td><td>"+languageIcon+"<td>" + doc.title + "</td><td><a href='javascript:showDetail("+index+");' class='btn btn-mini btn-primary'>Detail</a></td></tr>";
				counter++;
			});
			$("#resultListTableBody").html(tbody);
			console.log( "Num Pages");

			console.log( "Num Pages:" + nPages);
			console.log( "Current Page:" + cPage);
			console.log( "Start:" + start);

			var delta = 3;
			if(nPages>1){

				if(cPage == 1){
					paginationUl = "<li><span>&laquo;</span></li>";
					paginationUl += "<li><span>&lsaquo;</span></li>";
				}
				else{
					paginationUl = "<li><a href=\"javascript:goToPage("+parseInt(0)+")\">&laquo;</a></li>";
					paginationUl += "<li><a href=\"javascript:goToPage("+parseInt(cPage-2)+")\">&lsaquo;</a></li>";
				}
				if(cPage>delta){
					paginationUl += "<li><span>&hellip;</span></li>";
				}
				for(p = 1; p< nPages+1; p++){
					if(Math.abs(p-cPage)<delta){
						var active = "";
						if(cPage==p)
							active = "active";
						paginationUl += "<li class=\""+active+"\"><a href=\"javascript:goToPage("+parseInt(p-1)+")\">"+p+"</a></li>";
					}
				}
				if(nPages-cPage>=delta){
					paginationUl += "<li><span>&hellip;</span></li>";
				}
				if(cPage == nPages){
					paginationUl += "<li><span>&rsaquo;</span></li>";
					paginationUl += "<li><span>&raquo;</span></li>";
				}
				else{
					paginationUl += "<li><a href=\"javascript:goToPage("+parseInt(cPage)+")\">&rsaquo;</a></li>";
					paginationUl += "<li><a href=\"javascript:goToPage("+parseInt(nPages-1)+")\">&raquo;</a></li>";
				}
				$("#paginationUl").html(paginationUl);
			}
		}
	);
}


function showDetail(index){
	var doc = docs[index];
	var tbody = "";
	tbody += getDetailrow("Title", doc.title);
	tbody += getDetailrow("Package ID", doc.package_id);
	tbody += getDetailrow("Url", formatLinkUrl(doc.url) );
	tbody += getDetailrow("Language", formatLangIcon("4x3", doc.language));
	tbody += getDetailrow("Data type", doc.package_type);
	tbody += getDetailrow("Licence", doc.license_id);
	
	tbody += getDetailrow("Tags", formatList(doc.tag));
	tbody += getDetailrow("Concepts", formatList(doc.concept));
	tbody += getDetailrow("Authors", formatList(doc.author));
	tbody += getDetailrow("Description", doc.description);
	tbody += getDetailrow("Portal", doc.portal);
	tbody += getDetailrow("Metadata Origin", formatLinkUrl(doc.metadata_origin));
	tbody += getDetailrow("Metadata Created", doc.metadata_created);

	$("#resultDetailTableBody").html(tbody);
	scroolTo("detailPanelAnchor");
}




function getDetailrow(key, value){
	return "<tr><td><strong>" + key + "</strong></td><td>" + value + "</td></tr>";
}

function formatLinkUrl(url){
	var desc = url;
	if(desc.length>100)
		desc = url.substring(0,100) + "&hellip;";
	return "<a href='"+url +"' target='_blank' title='"+url+"'>" + desc +"</a>";
}

function formatLangIcon(type, language){
	if(language=='undefined')
		return "<span class='icon-question' aria-hidden='true'></span>";
	return "<div class='flag_"+type+"'><img src='flags/"+type+"/"+language+".svg' alt='"+language+"' title='"+language+" - "+ languages[language]+"' /></div>";
}

function formatList(list){
	var result = "";
	$.each(list,function(index, t){
		result +="<div>" + t + "</div>";
	});	
}


function clear(){
	$("#searchUrl").text("");
	$("#searchUrl").attr("href","");
	$("#resultDetailTableBody").html("");
	$("#paginationUl").html("");
	$("#info-message-panel").hide();
}

function goToPage(page){
	$("#paginationStart").text(parseInt(page*rowsInPage));
	search();
}

function numPages(){
	return Math.ceil(resultSize/rowsInPage);
}

function currentPage(){
	return Math.ceil(start/rowsInPage) +1;
}

function scroolTo( panelId){
	var top= $('#'+panelId).offset().top;
	$('html,body').animate({scrollTop:top}, 500);
}


